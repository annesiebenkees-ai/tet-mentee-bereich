# ChatGPT-Gedächtnis übernehmen

> **Anweisung an Claude.** Viele Nutzer haben vorher mit ChatGPT gearbeitet und dort schon viel Wissen über
> sich, ihr Business und ihre Marke aufgebaut. Mit dieser Anleitung holst du dieses Wissen herüber, sortierst
> es in die `context/`-Dateien ein und ergänzt nur noch, was fehlt — statt bei null anzufangen.
>
> Der Nutzer startet es mit: *„Lass uns mein ChatGPT-Gedächtnis übernehmen."*

---

## Warum das sinnvoll ist

Wenn der Nutzer ChatGPT länger genutzt hat, steckt dort oft schon eine Menge Kontext: in den **gespeicherten Erinnerungen** (Memory), in **Custom Instructions** und in alten **Chatverläufen**. Das ist ein fertiges Fundament — wir müssen es nur rüberziehen und ordnen.

---

## So holt der Nutzer sein ChatGPT-Wissen (führe ihn durch)

Erkläre ihm freundlich die drei Quellen — er muss nur **eine** liefern, mehr ist besser:

**Quelle 1 — Gespeicherte Erinnerungen (am schnellsten)**
> Öffne ChatGPT → klick oben rechts auf dein Profil → **Einstellungen → Personalisierung → Erinnerungen verwalten**.
> Dort steht alles, was sich ChatGPT über dich gemerkt hat. Markier den Text, kopier ihn und füg ihn hier einfach in den Chat ein.

**Quelle 2 — Custom Instructions / „Wie soll ChatGPT antworten?"**
> In ChatGPT → **Einstellungen → Personalisierung → Benutzerdefinierte Anweisungen**.
> Die beiden Textfelder („Was sollte ChatGPT über dich wissen?" und „Wie soll ChatGPT antworten?") enthalten oft deine Rolle, dein Business und deinen Wunsch-Ton. Kopier beide hier rein.

**Quelle 3 — Wichtige Chatverläufe (optional, für Tiefe)**
> Hast du einen langen Chat, in dem du dein Business/deine Positionierung mit ChatGPT erarbeitet hast?
> Kopier die wichtigsten Teile rein — oder exportiere deine Daten unter **Einstellungen → Datenkontrollen → Daten exportieren** (du bekommst eine ZIP per Mail) und leg die `conversations`-Datei in diesen Ordner. Sag mir Bescheid, dann lese ich sie.

---

## Was du mit dem Material machst

Sobald Text vorliegt:

1. **Lies alles und sortiere es selbst ein.** Ordne jede Aussage dem passenden Bereich zu:
   - Persönliches, Rolle, Hintergrund → `context/ueber-mich.md`
   - Produkte, Angebote, Projekte, Marken → `context/business-info.md`
   - Werte, Zielgruppe, Abgrenzung → `context/positionierung-zielgruppe.md`
   - Ton, Anrede, Schreibstil, Tabus → `context/brand-voice.md`
   - Farben, Schriften, Design → `context/branding-kit.md`
   - Ziele, Fokus, aktuelle Vorhaben → `context/strategie-ziele.md`
2. **Formuliere sauber um.** Nicht roh reinkopieren — bring es in die Struktur der Zieldateien, kürze Redundanz, behalte alles Konkrete.
3. **Markiere Lücken.** Was sich aus dem Material nicht ableiten lässt, sammelst du.
4. **Frag gezielt nach** — nur die echten Lücken, max. 3 Fragen pro Nachricht. Den Rest hast du ja schon.
5. **Veraltetes prüfen.** ChatGPT-Erinnerungen sind manchmal alt oder widersprüchlich. Wenn etwas unstimmig wirkt, frag kurz nach, statt es ungeprüft zu übernehmen.

---

## Abschluss

Wenn das Material eingearbeitet ist:

1. Zeig dem Nutzer in 4–6 Sätzen, was du aus seinem ChatGPT-Wissen übernommen hast.
2. Nenne die verbliebenen Lücken und biete an, sie mit den passenden Fragen aus `reference/fundament-interview.md` zu schließen.
3. Schließe ab mit:

> ✅ Dein ChatGPT-Wissen ist übernommen und sortiert. Ich starte also nicht bei null — ich kenne dich schon. Lass uns nur noch die paar offenen Punkte ergänzen, dann steht dein Fundament komplett.

---

## Ton

Anerkennend („du hast ja schon viel vorgearbeitet"), entlastend, effizient. Der Nutzer soll merken: nichts geht verloren, und es geht schneller, als er dachte.

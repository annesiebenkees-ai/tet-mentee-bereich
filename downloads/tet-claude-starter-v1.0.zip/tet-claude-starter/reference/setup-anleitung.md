# Setup-Anleitung — dein Fundament in 11 Schritten

> Diese Anleitung führt dich durch den kompletten Aufbau: erst die einmalige Installation (Schritte 1–3),
> dann lernt dich dein Claude kennen (Schritte 4–11). Du kannst ihr selbst folgen — oder ab Schritt 3
> einfach deinem Claude sagen: *„Führ mich durch das Setup."* Dann übernimmt er die Führung.

---

## Bevor du startest

Du brauchst:
- **Claude Code** — die Desktop-App von `claude.ai/code` (inkl. Claude-Abo). Richten wir in Schritt 1 ein.
- **GitHub** — kostenloser Account + GitHub Desktop. Richten wir in Schritt 2 ein.
- ~60 Minuten Zeit (Installation + Fundament), du kannst jederzeit pausieren
- Optional: ein **Brandkit-PDF** (Farben/Schriften) und dein **ChatGPT-Wissen**, falls vorhanden

Du musst **keine Dateien selbst bearbeiten**. Du sprichst, Claude schreibt.

---

## Schritt 1 — Claude Code installieren & einloggen

Claude Code ist die App, in der dein ganzes Tool läuft — und Claude darin dein persönlicher Assistent.

- Geh auf `claude.ai/code` und lade die **Desktop-App** für dein Betriebssystem herunter:
  - **Mac:** die `.dmg`-Datei öffnen, App in den Programme-Ordner ziehen
  - **Windows:** die `.exe`-Datei ausführen, dem Installationsassistenten folgen
- Öffne Claude Code aus deinen Apps und **logge dich mit deinem Claude-Account ein**
- Claude Code läuft mit einem **Pro- oder Max-Abo** (~20 €/Monat) — ein Gratis-Tier gibt es nicht. Noch kein Abo? Auf `claude.ai` Account anlegen und Pro wählen.

Keine Admin-Rechte oder technisches Vorwissen nötig — eine ganz normale App-Installation. Den Zugangslink findest du auch in deiner Kauf-/Willkommens-Mail.

---

## Schritt 2 — GitHub einrichten

Claude Code arbeitet im Hintergrund mit „Git" (ein automatisches Backup mit Zeitmaschine). Über **GitHub** bekommt dein Workspace zusätzlich ein **privates Cloud-Backup** — streikt dein Rechner mal, ist alles noch da. Einmal einrichten, danach nie wieder:

- Lege dir einen **kostenlosen Account** auf `github.com` an (Free-Plan reicht)
- Lade **GitHub Desktop** von `desktop.github.com` herunter und installiere es — damit ist „Git" automatisch mitinstalliert (kein Terminal, keine Befehle)
- Öffne GitHub Desktop und **logge dich mit deinem GitHub-Account ein**
- **Starte deinen Rechner einmal neu** — danach ist Git überall erkannt
- Verbinde GitHub anschließend in **Claude Code** (Einstellungen → Connectors / GitHub → einloggen)

Ab jetzt sicherst du deinen Stand jederzeit mit: *„Sichere den aktuellen Stand auf GitHub."* — Claude erledigt das Git-technische für dich. Klemmt etwas („Git wird nicht erkannt")? Sag deinem Claude genau das, er führt dich durch die Lösung.

---

## Schritt 3 — Diesen Ordner laden & loslegen

Jetzt bringst du dieses Tool in Claude Code. Falls du es als ZIP bekommen hast: erst **entpacken**.

- Öffne Claude Code und wähle **„Ordner öffnen / hinzufügen"**
- Wähle diesen **entpackten Tool-Ordner** (der mit `START-HIER.html` und `CLAUDE.md` darin)
- Kopier dann diesen Satz in den Chat:

> 💬 Hallo! Ich richte gerade mein Claude-Fundament ein. Bitte lies die CLAUDE.md und führe mich Schritt für Schritt durch das Setup.

Claude begrüßt dich, liest den Workspace ein und führt dich ab hier durch alles Weitere.

---

## Schritt 4 — (Optional) ChatGPT-Gedächtnis übernehmen

Hast du vorher mit ChatGPT gearbeitet? Dann hol dein dortiges Wissen rüber, bevor du neu anfängst:

> 💬 Lass uns mein ChatGPT-Gedächtnis übernehmen.

Claude führt dich, welche drei Quellen du wie kopierst (Erinnerungen, Custom Instructions, Chatverläufe), sortiert alles in deine Dateien ein und fragt nur nach, was fehlt. Details: `reference/chatgpt-gedaechtnis-uebernehmen.md`.

---

## Schritt 5 — Das Fundament-Interview

Der Kern. Hier lernt Claude dich richtig kennen:

> 💬 Lass uns mein Fundament aufbauen.

Claude führt dich durch sechs Bereiche (Über dich · Business · Positionierung & Zielgruppe · Brand Voice · Branding Kit · Strategie & Ziele) und schreibt deine Antworten sauber in die `context/`-Dateien. ~30–40 Min. Du kannst pausieren — er speichert unterwegs.

---

## Schritt 6 — Branding Kit hinterlegen

Wenn du ein Brandkit-PDF oder eine Farbpalette hast, gib sie Claude:

> 💬 Hier ist mein Brandkit — lies die Farben und Schriften aus und trag sie ein.

So weiß Claude, wie deine Marke aussieht — wichtig für alles Visuelle.

---

## Schritt 7 — Brand Voice schärfen

Gib Claude 2–3 echte Sätze, die typisch für dich klingen (aus alten Posts/Captions):

> 💬 So klinge ich — kalibrier meinen Ton daran: [deine Beispielsätze]

Je echter die Beispiele, desto markentreuer schreibt Claude später.

---

## Schritt 8 — CLAUDE.md personalisieren

Lass Claude den Kopf der CLAUDE.md auf dich zuschneiden:

> 💬 Personalisiere die CLAUDE.md mit meinem Namen, Business und meinen Hauptzielen.

Damit sitzt der erste Eindruck in jeder zukünftigen Session sofort.

---

## Schritt 9 — Dauer-Gedächtnis aktivieren

Lass Claude die wichtigsten, stabilen Fakten dauerhaft sichern:

> 💬 Merk dir die wichtigsten Fakten über mich dauerhaft.

So bleibt dein Profil auch über einzelne Sessions hinaus erhalten und wächst mit dir.

---

## Schritt 10 — Lücken prüfen & schließen

Frag Claude, ob noch etwas fehlt:

> 💬 Gibt es in meinem Fundament noch Lücken? Frag mich, was fehlt.

Er zeigt dir offene Punkte und ergänzt sie mit dir im Gespräch.

---

## Schritt 11 — Testlauf

Starte eine **neue** Session und ruf auf:

> 💬 /prime

Claude fasst zusammen, was er jetzt über dich weiß. Sitzt alles? Dann steht dein Fundament. Fehlt etwas, ergänz es einfach im Gespräch — Claude trägt es nach.

---

## Geschafft

Ab jetzt startet jede Session mit `/prime`, und Claude ist sofort auf deinem Stand — ohne dass du dich je wieder erklären musst. Dein Fundament wächst mit dir: Erzähl Claude Neues, und er merkt es sich dazu.

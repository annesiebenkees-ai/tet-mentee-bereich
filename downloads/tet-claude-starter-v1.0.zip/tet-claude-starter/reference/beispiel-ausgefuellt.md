# Beispiel — ein fertig ausgefülltes Fundament

> **Nur zur Orientierung.** Dies ist ein fiktives Beispiel (Marke „Sonnenklar Coaching"), damit du siehst,
> wie ein fertiges Fundament aussieht. Das System liest diese Datei NICHT — sie ist nur dein Vorbild.

---

## context/ueber-mich.md

**Wer ich bin:** Ich bin Lena, Online-Coach, und ich helfe überforderten Solo-Selbstständigen, ihr Business ohne Dauerstress zu führen.

**Mein Hintergrund:** Zehn Jahre im Marketing-Hamsterrad, Burnout mit 32, danach selbst alles neu aufgebaut — diesmal mit System statt Selbstausbeutung. Genau das gebe ich heute weiter.

**Meine Rolle:** Solo-Unternehmerin. Ich mache alles selbst: Content, Coaching, Verkauf — und will genau das schlanker und automatisierter aufstellen.

**Mein Warum:** Ich kann nicht zusehen, wie kluge Frauen sich kaputtarbeiten, weil ihnen niemand gezeigt hat, dass es auch anders geht.

---

## context/business-info.md

**In einem Satz:** Ich biete 1:1-Coaching und einen Gruppenkurs für Solo-Selbstständige, die nachhaltig wachsen wollen.

**Marke 1: Sonnenklar Coaching**
- Kern: Anti-Hustle-Business-Coaching
- Produkte: 1:1-Coaching (3 Monate), Gruppenkurs „Klar & ruhig wachsen", kostenloses Workbook
- USP: Fokus auf weniger statt mehr — Systeme, die ohne Dauerpräsenz laufen
- Phase: im Aufbau, erste zahlende Kundinnen da
- Kanäle: Instagram @sonnenklar.coaching, Website

---

## context/positionierung-zielgruppe.md

**Was ich ausstrahle:** Ruhe, Klarheit, Machbarkeit.
Werte: Ehrlichkeit (kein Erfolgs-Theater), Leichtigkeit, Substanz.

**Zielgruppe:** Frauen 30–45, solo-selbstständig, kreativ oder beratend, ständig am Limit. Wünscht sich: ein Business, das trägt, ohne sie aufzufressen. Hält sie zurück: der Glaube, sie müsse „mehr posten, mehr machen". Stille Frage: „Bin ich die Einzige, der das alles zu viel ist?"

**Wo ich anders bin:** Während andere „Skaliere auf 6-stellig" rufen, sage ich: erst Fundament, dann Wachstum.

**🎯 Statement:** Ich zeige Solo-Selbstständigen, wie ihr Business ruhig und planbar wächst — ohne dass sie sich dabei selbst verlieren.

---

## context/brand-voice.md

**Anrede:** Du, persönlich, „meine Liebe" sparsam.
**Ton:** warm, klar, ermutigend, unaufgeregt, ehrlich.
**Tabus:** Hustle-Sprech, „Boss-Babe", Druck-Rhetorik, Ausrufezeichen-Gewitter.
**No-Gos:** Kein hohles Lob („Tolle Idee!"), nicht um den heißen Brei reden, keine generischen Coaching-Floskeln.
**Referenzen:** @account_x (ruhiger Ton), @account_y (klare Struktur).
**Beispielsätze:**
> „Du musst nicht lauter werden. Du musst klarer werden."
> „Weniger posten, mehr meinen — das funktioniert."

---

## context/branding-kit.md

**Farben:** Primär Terrakotta #C56B4A, Akzent Salbei #8FA68E, Hintergrund Creme #F6F1E9.
**Schriften:** Überschriften „Fraunces", Fließtext „Inter".
**Logo:** Wortmarke + kleine Sonne als Bildmarke.
**Bildsprache:** warm, natürlich, viel Licht; keine kalten Stockfotos.
**Formate:** v.a. Karussells & Stories, 1080×1350.

---

## context/strategie-ziele.md

**Fokus (1–3 Monate):** Sichtbarkeit aufbauen, Gruppenkurs zum ersten Mal füllen.
**Ziele:** 2.000 echte Follower · 10 Kursplätze verkauft · Content-Erstellung automatisiert.
**Erfolg sieht so aus:** Ich poste regelmäßig, ohne dass es mich erschöpft, und der Kurs ist voll.
**Offene Baustellen:** Funnel steht noch nicht; Preisgestaltung Gruppenkurs unklar.
**Wofür ich Claude eingestellt habe:** Content planen & vorschreiben, Captions in meinem Ton, Strukturen aufbauen, mitdenken.
**Rolle für Claude:** Sparringspartner mit klarer Meinung — kein Ja-Sager. Soll widersprechen, wenn etwas nicht trägt, und Vorschläge machen statt nur abzunicken.

# inbox/

Dein Notizzettel: wirf hier schnelle Ideen, Links oder halbe Sätze rein. Sag Claude später einfach „Schau in meine inbox und arbeite die Notizen durch" — er greift sie auf und macht was draus.

# Start

> Alias für `/prime` — schnellerer Einstiegspunkt, um eine neue Session zu starten.

Führe `/prime` aus: Lies `CLAUDE.md` und alle Dateien in `./context/`, dann fasse zusammen, wer der Nutzer ist, was sein Business ist, wie seine Marke klingt und aussieht und worauf er hinarbeitet. Bestätige deine Bereitschaft zu helfen.

# Prime

> Führe die folgenden Schritte aus, um dein Fundament zu laden und dann dein Verständnis zusammenzufassen.

## Lesen

- `CLAUDE.md`
- alle Dateien in `./context/`

## Zusammenfassung

Nach dem Lesen liefere kurz und warm:

1. **Wer der Nutzer ist** — Name, Rolle, in 1–2 Sätzen.
2. **Sein Business** — was er macht, welche Marke(n), aktuelle Phase. Bei mehreren Marken sauber getrennt.
3. **Seine Marke** — wie sie klingt (Voice) und aussieht (Branding), in Stichworten.
4. **Worauf er hinarbeitet** — aktueller Fokus und Hauptziele.
5. **Bestätigung**, dass du bereit bist, ihn dabei zu unterstützen.

Wenn das Fundament noch Platzhalter (`[…]`) enthält, weise freundlich darauf hin, welche Bereiche noch fehlen, und biete an, sie jetzt gemeinsam zu füllen (`reference/fundament-interview.md`).

Halte es prägnant — der Nutzer soll am Ende fühlen: „Claude kennt mich."

# Positionierung & Zielgruppe

> Diese Datei beschreibt, **wofür du stehst und wen du erreichst**. Sie ist das inhaltliche Fundament,
> aus dem später jeder Hook, jede Botschaft und jeder Beitrag entsteht.

---

## Was ich ausstrahle

[Wofür du wahrgenommen werden willst]

**Meine Werte:**
- [Wert 1 — weil …]
- [Wert 2 — weil …]
- [Wert 3 — weil …]

## Meine Zielgruppe

[Wer dein idealer Kunde/Follower ist: Alter, Alltag, Lebenssituation]

**Ihre Sehnsucht:** [Was sie sich wünscht]
**Ihr Schmerz / was sie zurückhält:** [Hindernisse, Zweifel]
**Stille innere Fragen:** [Was sie sich fragt, aber nie laut sagt]

## Wo ich anders bin

[2–3 vergleichbare Anbieter — was die gut machen, und wo deine Lücke ist]

## 🎯 Mein Positionierungs-Statement

> [Ein Satz in Ich-Form, der in 30 Sek. klarmacht, wofür du stehst — kein Marketingsprech]

---

_Bei mehreren Marken: pro Marke eine eigene Positionierung. Niemals vermischen._

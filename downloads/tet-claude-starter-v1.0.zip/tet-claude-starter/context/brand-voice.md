# Brand Voice — wie meine Marke klingt

> Diese Datei beschreibt, **WIE** deine Marke klingt. Je konkreter, desto markentreuer schreibt Claude
> später deine Texte, Captions und Beiträge. Bei mehreren Marken: pro Marke ein eigener Block.

---

## Anrede

[Du oder Sie? Wie sprichst du deine Leute an — z.B. „Liebe", „du da draußen", neutral]

## Ton

[3–5 Adjektive — wie soll es sich anfühlen? z.B. warm & direkt / sachlich & souverän / frech & verspielt]

## Tabus

[Wörter, Floskeln, Töne, die gar nicht gehen. Worüber du nie redest.]

## No-Gos (was Claude NIE tun soll)

[Konkrete Verhaltens-Verbote — gelten in jeder Antwort und jedem Text. Beispiele:]
- [z.B. Kein hohles Lob wie „Tolle Idee!" — direkt zur Sache]
- [z.B. Nicht zu lang erklären — kurz und auf den Punkt]
- [z.B. Keine Marketing-Floskeln / kein Coaching-Geschwätz]

## Referenz-Accounts

- [Account/Marke 1 — was du am Ton magst]
- [Account/Marke 2 — was du am Ton magst]

## Beispielsätze (so klinge ich)

> [Echter Satz 1 — typisch für dich]
> [Echter Satz 2]
> [Echter Satz 3]

---

_Diese Beispielsätze sind Gold für die Tonkalibrierung — je echter, desto besser._

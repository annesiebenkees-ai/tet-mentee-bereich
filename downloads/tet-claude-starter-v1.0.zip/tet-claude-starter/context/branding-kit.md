# Branding Kit — wie meine Marke aussieht

> Diese Datei beschreibt, **WIE** deine Marke visuell aussieht. Claude nutzt sie, sobald es um Design,
> Grafiken oder Vorlagen geht. Hast du ein Brandkit-PDF? Gib es Claude — er liest die Werte aus.

---

## Farben

| Rolle | Farbe | HEX-Code |
| ----- | ----- | -------- |
| Primärfarbe | [z.B. Navy] | [#______] |
| Akzentfarbe | [z.B. Hellblau] | [#______] |
| Sekundär / Warm | [z.B. Camel] | [#______] |
| Hintergrund | [z.B. Creme] | [#______] |

## Schriften

- **Überschriften:** [Schriftname, z.B. Playfair Display]
- **Fließtext:** [Schriftname, z.B. Helvetica Neue]

## Logo & visuelle Elemente

[Logo vorhanden? Maskottchen? Wiederkehrende Formen/Bildwelten?]

## Bildsprache

[Welche Art Bilder passt — hell & clean / warm & nah / bold & grafisch? Was gar nicht?]

## Format-Hinweise

[Bevorzugte Formate (Karussells, Reels, Stories), Plattform-Maße]

---

_Wenn ein Brandkit-PDF vorliegt, liest Claude die Werte sorgfältig aus — nicht raten._

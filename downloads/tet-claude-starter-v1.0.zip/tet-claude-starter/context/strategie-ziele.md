# Strategie & Ziele

> Diese Datei beschreibt, **worauf du gerade hinarbeitest**. Claude liest sie, um als Denkpartner auf
> deine Ziele ausgerichtet zu handeln — nicht beliebig, sondern in deine Richtung.

---

## Fokus-Zeitraum

[Worauf konzentrierst du dich die nächsten 1–3 Monate?]

## Konkrete Ziele

- [Ziel 1 — möglichst messbar: Follower, Umsatz, Launch, Reichweite]
- [Ziel 2]
- [Ziel 3]

## Wie Erfolg aussieht

[Woran merkst du, dass es funktioniert?]

## Offene Fragen / Baustellen

[Welche Entscheidungen sind noch offen? Wo hängst du gerade?]

## Wofür ich Claude „eingestellt" habe

[Was soll Claude für dich übernehmen — deine wichtigsten Aufträge an ihn]

## Welche Rolle Claude einnehmen soll

[Wie soll Claude dir gegenübertreten? z.B. „Stratege & Sparringspartner mit klarer Meinung — kein Ja-Sager", „ruhiger Umsetzer", „kreativer Ideengeber". Soll er widersprechen, wenn er etwas anders sieht?]

---

_Aktualisieren, wenn sich Prioritäten verschieben. Veraltete Ziele lenken die Arbeit in die falsche Richtung._

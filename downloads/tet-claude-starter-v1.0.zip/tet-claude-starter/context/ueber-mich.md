# Über mich

> Diese Datei beschreibt, **wer du bist**. Claude liest sie zu Beginn jeder Session, um dich zu verstehen.
> Du musst sie nicht selbst ausfüllen — Claude trägt deine Antworten aus dem Fundament-Interview hier ein.

---

## Wer ich bin

[Name + ein Satz: was du machst / wofür du sorgst]

## Mein Hintergrund

[Was dich dahin gebracht hat, wo du heute bist — was deine Arbeit prägt]

## Meine Rolle

[Gründerin / Solo-Unternehmerin / Angestellte / im Team — und wofür du konkret verantwortlich bist]

## Mein Warum

[Warum du das machst — das ehrliche Warum, nicht das Marketing-Warum]

## Markt & Sprache

[Wo bist du aktiv (z.B. DACH-Raum) und gibt es eine Sprachfärbung? z.B. „österreichisch gefärbtes Deutsch", „Schweizer Kund:innen", lockeres Du]

## Wichtiger Lebenskontext

[Optional: Persönliches, das deine Arbeit prägt — nur wenn relevant fürs Business]

---

_Claude hält diese Datei aktuell, wenn sich etwas Grundlegendes über dich ändert._

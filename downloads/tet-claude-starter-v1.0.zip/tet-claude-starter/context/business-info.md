# Mein Business

> Diese Datei beschreibt, **was du tust und verkaufst**. Claude nutzt sie als organisatorischen Rahmen.
> Hast du mehrere Marken/Projekte? Dann legt Claude pro Marke einen eigenen Abschnitt an — sauber getrennt.

---

## Mein Business in einem Satz

[Was du anbietest, für wen]

## Marke / Projekt 1: [Name]

- **Kern:** [Worum es geht]
- **Produkte / Dienstleistungen:** [Was du genau anbietest]
- **USP:** [Was du kannst, das andere nicht]
- **Phase:** [Frisch gestartet / im Aufbau / etabliert / im Umbruch]
- **Kanäle:** [Instagram-Handle, Shop, Website, Offline …]

<!-- Bei mehreren Marken kopiert Claude diesen Block pro Marke. Jede Marke bleibt eigenständig:
     eigene Tonalität, eigene Zielgruppe, eigene Strategie — niemals vermischen. -->

---

## Wichtiger Kontext

[Markt­position, Team, aktuelle Änderungen — was Claude sonst noch wissen sollte]

---

_Auf hohem Niveau halten — genug zur Orientierung, kein vollständiges Unternehmens-Wiki._

# Das Framework hinter `/landingpage` (zum Nachlesen)

> Du musst das nicht auswendig können — Claude wendet es automatisch an. Hier nur, damit du verstehst,
> *warum* deine Seiten verkaufen, und gezielt nachsteuern kannst.

## Die 5 Awareness-Level (Eugene Schwartz)
Wie bewusst ist deiner Zielgruppe ihr Problem? Das bestimmt, womit die Seite einsteigt.

1. **Unaware** – kennt das Problem nicht → mit Story/Problem öffnen
2. **Problem-aware** – kennt das Problem, nicht die Lösung
3. **Solution-aware** – kennt Lösungswege, nicht dich
4. **Product-aware** – kennt dich, noch nicht überzeugt
5. **Most aware** – bereit → direkt zum Angebot/CTA

Je „kälter" der Traffic, desto mehr Problem-/Beweisarbeit oben. Je „wärmer", desto direkter zum Angebot.

## Die Wert-Formel (Alex Hormozi)
**(Traumergebnis × Wahrscheinlichkeit) ÷ (Zeit × Aufwand)**
→ oben maximieren, unten minimieren, Risiko eliminieren. Macht dein Angebot unwiderstehlich, ohne Druck.

## Traffic-Bridge
Die Seite greift oben auf, woher der Besucher kommt („Du hast gerade das Reel gesehen …"). Das schafft Anschluss und senkt die Absprungrate.

## 3 Hero-Varianten
Claude baut aus deinem Roh-Hook drei Headline-Varianten (nah / emotionaler / provokanter), empfiehlt eine und markiert alle drei im Code — perfekt für A/B-Tests.

## Ehrlichkeit als Prinzip
Keine erfundenen Testimonials, Namen, Zahlen oder Garantien. Echte Belege setzt du ein. Das hält deine Seite glaubwürdig und rechtssicher.

---

**Steuern per Zuruf:** „Mach Hook B live" · „Kürze den Vertrauens-Block" · „Schreib emotionaler" · „Bau eine Variante für kälteren Traffic" — Claude passt an.

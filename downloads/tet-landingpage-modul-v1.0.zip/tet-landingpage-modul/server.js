const http=require('http'),fs=require('fs'),path=require('path');
const dir=__dirname,port=4006;
http.createServer((req,res)=>{let f=path.join(dir,req.url==='/'?'START-HIER.html':req.url);fs.readFile(f,(e,d)=>{if(e){res.writeHead(404);res.end('404');return;}const ext=path.extname(f);res.writeHead(200,{'Content-Type':ext==='.html'?'text/html':'text/plain'});res.end(d);});}).listen(port);
console.log('Modul on '+port);

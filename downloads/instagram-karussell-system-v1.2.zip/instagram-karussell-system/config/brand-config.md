# Brand-Konfiguration

> **Das ist die EINZIGE Datei, die du aktiv ausfüllen musst.**
> Trag deine Werte zwischen die `[ECKIGEN KLAMMERN]` (die Klammern selbst löschst du mit).
> Das gesamte System liest seine Einstellungen aus dieser Datei. Alle anderen Dateien bleiben unverändert.
>
> Weißt du nicht, was wohin gehört? Die `reference/setup-anleitung.md` führt dich Feld für Feld durch. Oder frag deinen Claude: „Hilf mir, brand-config.md auszufüllen."
>
> 👀 **Wie sieht das fertig aus?** In `config/beispiel-ausgefuellt.md` findest du eine komplett ausgefüllte Beispiel-Config (fiktive Marke) als Orientierung.

---

## Marke

```yaml
brand_name: "[MARKENNAME]"                  # z.B. "Sonnenklar Coaching"
instagram_handle: "[INSTAGRAM_HANDLE]"      # ohne @, z.B. "sonnenklar.coaching"
instagram_niche: "[NISCHE]"                 # z.B. "Online-Business", "Windelfrei", "Fitness", "Ernährung"
```

---

## Canva

> Diese IDs ermittelst du in den Canva-Schritten der Setup-Anleitung. Eine Canva-Ordner-ID steht in der URL:
> `https://www.canva.com/folder/`**`FAHMkGrQhr8`** ← das ist die ID.

```yaml
canva_template_design_id: "[DESIGN-ID]"               # ID deines fertig gebauten Karussell-Templates
canva_folder_id: "[ORDNER-ID PRODUZIERT]"             # Ordner für neu produzierte Designs
canva_posting_queue_folder_id: "[ORDNER-ID QUEUE]"    # Ordner für freigegebene Designs (Posting Queue)
canva_gepostet_folder_id: "[ORDNER-ID ARCHIV]"        # Ordner für bereits gepostete Designs
```

---

## Template-Element-IDs

> Einmalig per `start-editing-transaction` auf deinem Template ermitteln (siehe Setup-Anleitung).
> Dein Claude öffnet die Transaction, liest die Element-IDs der Textfelder aus, und du trägst sie hier ein.
> **Wichtig:** Liste GENAU die Textelemente, die pro Karussell ausgetauscht werden sollen — so viele Slides
> wie dein Template hat. Lösch die Beispielzeilen, die du nicht brauchst, und ergänze weitere bei Bedarf.

```yaml
slides_per_carousel: [ANZAHL]            # Anzahl Seiten deines Templates, z.B. 3

text_elements:
  - slide: 1
    rolle: "hook"                        # Cover/Hauptaussage
    element_id: "[ELEMENT-ID]"
  - slide: 1
    rolle: "cta"                         # Call-to-Action auf dem Cover
    element_id: "[ELEMENT-ID]"
  - slide: 2
    rolle: "content"                     # Mehrwert-Text
    element_id: "[ELEMENT-ID]"
  # - slide: 3
  #   rolle: "content"
  #   element_id: "[ELEMENT-ID]"
```

---

## Blotato

> Verbinde Blotato erst (siehe Setup-Anleitung), dann frag deinen Claude:
> „Zeige mir meine verbundenen Blotato-Accounts." und trag die accountId für dein Instagram hier ein.
> Solange hier der Platzhalter steht, läuft das Posting im **Hinweis-Modus** (es wird nichts gepostet,
> nur angezeigt, was bereit wäre).

```yaml
blotato_account_id: "[BLOTATO_ACCOUNT_ID]"
```

---

## Posting

```yaml
posting_slots:                  # Uhrzeiten, zu denen pro Tag gepostet wird
  - "09:00"
  - "13:00"
  - "18:00"
timezone: "Europe/Berlin"
carousels_per_week: [ANZAHL]    # z.B. 21 (3/Tag) oder 7 (1/Tag) — bestimmt, wie viel Claude wöchentlich produziert
max_posts_per_run: [ANZAHL]     # max. Posts, die der tägliche Task pro Lauf einplant, z.B. 3
```

---

## Content-Kategorien

> Wie sich deine Karussells inhaltlich aufteilen. Die Summe der `anteil`-Werte sollte `carousels_per_week` ergeben.
> Du kannst beliebig viele Kategorien anlegen — ergänze oder lösche Blöcke nach Bedarf.

```yaml
kategorien:
  - name: "[KATEGORIE 1]"          # z.B. "Praxis"
    anteil: [ANZAHL/WOCHE]         # z.B. 8
    beschreibung: "[Was diese Posts zeigen]"
  - name: "[KATEGORIE 2]"
    anteil: [ANZAHL/WOCHE]
    beschreibung: "[...]"
  - name: "[KATEGORIE 3]"
    anteil: [ANZAHL/WOCHE]
    beschreibung: "[...]"
```

---

## Zielgruppe

> 💡 Hast du deine **Positionierung** schon in `context/positionierung.md` eingetragen? Dann kann Claude
> `zielgruppe`, `kernbotschaft` und sogar Vorschläge für `kategorien` und `recherche_themen` direkt
> daraus ableiten. Sag einfach: „Übernimm die passenden Felder aus meiner Positionierung."

```yaml
zielgruppe: "[Kurzbeschreibung: Wer ist deine ideale Followerin/dein idealer Follower?]"
kernbotschaft: "[Was soll JEDER Post implizit vermitteln? In einem Satz.]"
```

---

## Themen für Trendrecherche

> Schlagworte, nach denen Claude wöchentlich nach aktuellen Trends/Diskussionen sucht,
> um deine Karussells aktuell zu halten.

```yaml
recherche_themen:
  - "[Thema 1]"
  - "[Thema 2]"
  - "[Thema 3]"
```

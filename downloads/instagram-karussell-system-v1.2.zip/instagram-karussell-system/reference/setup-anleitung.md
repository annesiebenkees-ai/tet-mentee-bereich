# Setup-Anleitung: Dein automatisches Instagram-Karussell-System

Willkommen! 🎉 In dieser Anleitung richtest du Schritt für Schritt dein eigenes Karussell-System ein. **Du brauchst kein technisches Vorwissen.** Dein Claude führt dich durch jeden Schritt — wenn du irgendwo nicht weiterkommst, schreib einfach: *„Hilf mir bei Schritt X der Setup-Anleitung."*

Plane einmalig ca. **1,5–2 Stunden** für die Einrichtung ein (inkl. Positionierung). Danach läuft alles automatisch.

---

## 0. Was du hier bekommst

Ein System, das **jede Woche automatisch** Instagram-Karussells für deine Marke produziert — in deinem Branding, mit recherchierten Themen und fertigen Captions, die auf deiner echten Positionierung aufbauen. Du prüfst sie nur noch kurz und gibst sie frei, der Rest wird automatisch auf Instagram eingeplant.

> **Was ein Social-Media-Manager für 500–2.000 €/Monat macht, erledigt dein Claude für ~20 €/Monat.**

So läuft es nach dem Setup:
- **Wöchentlich:** Claude recherchiert, erstellt deine Karussells und legt sie in `zur-pruefung/` ab
- **Du:** Schaust drüber, verschiebst die guten nach `bereit-zum-posten/`
- **Täglich:** Claude exportiert und plant die freigegebenen Karussells über Blotato auf Instagram ein

---

## 1. Voraussetzungen

Du brauchst:

- ✅ **Claude Code** (installiert und eingerichtet) — die App, in der du das hier liest
- ✅ Einen **Canva-Account** (Pro empfohlen, damit du eigene Schriften/Marken nutzen kannst)
- ✅ Einen **Blotato-Account** (für das automatische Posten auf Instagram) — [blotato.com](https://blotato.com)
- ✅ Deinen **Instagram-Account** (am besten ein Business- oder Creator-Account)

---

## 2. MCP-Server verbinden (Canva + Blotato)

„MCP-Server" sind die Brücken, über die dein Claude mit Canva und Blotato spricht.

1. Öffne in Claude Code die **Einstellungen → MCP Servers**
2. Füge den **Canva**-Server hinzu (folge dem Verbindungs-Dialog, du wirst einmalig bei Canva eingeloggt)
3. Füge den **Blotato**-Server hinzu (ebenso)
4. Teste die Verbindung — sag deinem Claude: *„Liste meine Canva-Ordner auf."* Wenn eine Liste kommt, funktioniert Canva. ✅

> Klappt eine Verbindung nicht? Sag: *„Der Canva-MCP-Server verbindet nicht — hilf mir."*

---

## 3. Deine Positionierung 🔥 (das Fundament)

**Das ist der wichtigste inhaltliche Schritt** — und der Grund, warum deine Karussells später wirklich treffen statt beliebig zu sein. Bevor wir Design und Technik anfassen, klären wir, *wofür* du stehst und *wen* du erreichst.

1. Sag deinem Claude: *„Lass uns meine Positionierung erarbeiten."*
2. Er führt dich durch ein kurzes Interview — entweder 9 Fragen von Grund auf (ca. 20–30 Min.) oder über deinen Freitext, wenn du schon etwas hast.
3. Am Ende steht deine fertige Positionierung in `context/positionierung.md` — das Fundament für jeden Hook und jede Botschaft.

> 💡 Dieser Schritt spart dir später Arbeit: Aus deiner Positionierung kann Claude die Zielgruppe, Kernbotschaft und sogar Content-Kategorien für die `brand-config.md` direkt ableiten.

---

## 4. Dein Canva-Template einmalig bauen

Der wichtigste manuelle Schritt — und du machst ihn nur **ein einziges Mal**.

1. Erstelle in Canva ein neues **Instagram-Karussell** (Format 1080 × 1350 px, hochkant)
2. Baue **3–7 Seiten** mit deinem echten Branding: Logo, Farben, Schriften, ggf. Maskottchen oder Foto
3. Auf jede Seite kommt ein **Platzhalter-Textfeld** dort, wo später der wechselnde Text steht:
   - Seite 1: ein großes Feld für den **Hook** + ein kleines für den **CTA**
   - Folgeseiten: je ein Feld für den **Inhalt/Mehrwert**
   - Schreib zum Test irgendetwas rein, z.B. „Hier steht der Hook"

> ⚠️ **Wichtig — nicht von Claude generieren lassen.** Lass das Template NICHT über `generate-design` erstellen. Das liefert nur generische, farbige Designs ohne dein echtes Branding. Multi-Page-Templates mit deinem Branding müssen **einmalig manuell in Canva** gebaut werden. Danach kann Claude es beliebig oft kopieren und befüllen.

---

## 5. Template-Design-ID + Element-IDs ermitteln

Jetzt holen wir die „Adressen" deiner Textfelder, damit Claude weiß, wo er Text einsetzen soll.

1. **Design-ID:** Öffne dein Template in Canva. Die ID steht in der URL: `canva.com/design/`**`DAF...xyz`**`/edit`. Notiere sie.
2. **Element-IDs:** Sag deinem Claude:
   > *„Öffne eine `start-editing-transaction` auf das Canva-Design [DEINE-DESIGN-ID] und zeig mir die Element-IDs aller Textfelder. Danach cancel die Transaction wieder."*
3. Claude listet dir die Textelemente mit ihren IDs auf. Notiere, welche ID zu welchem Feld gehört (Hook, CTA, Inhalt Seite 2, …).

---

## 6. Canva-Ordner anlegen + IDs notieren

Lege in Canva drei Ordner an (oder lass Claude sie anlegen):

| Ordner | Zweck |
| --- | --- |
| **Produzierte Karussells** | Hier landen neu erstellte Designs |
| **Posting Queue** | Freigegebene Designs |
| **Gepostet** | Archiv |

Die Ordner-ID steht in der URL: `canva.com/folder/`**`FAH...abc`**. Notiere alle drei.

---

## 7. Blotato verbinden + accountId ermitteln

1. Verknüpfe in [Blotato](https://blotato.com) deinen Instagram-Account
2. Sag deinem Claude: *„Zeige mir meine verbundenen Blotato-Accounts."*
3. Notiere die **accountId** für deinen Instagram-Account

> Blotato noch nicht startklar? Kein Problem — du kannst alles andere schon einrichten. Solange die `blotato_account_id` leer bleibt, läuft das Posting im **Hinweis-Modus**: Claude zeigt dir dann nur an, was bereit wäre, postet aber noch nichts.

---

## 8. `brand-config.md` ausfüllen

Jetzt trägst du alle notierten Werte in **eine einzige Datei** ein: `config/brand-config.md`.

- Öffne sie und ersetze alle `[PLATZHALTER]` durch deine Werte (Markenname, Handle, die Canva-IDs aus Schritt 5–6, die Element-IDs, die Blotato-accountId aus Schritt 7, Posting-Slots, Kategorien, Zielgruppe, Recherche-Themen)
- Oder lass dir helfen: *„Hilf mir, `brand-config.md` Feld für Feld auszufüllen."*
- 🔥 **Hast du Schritt 3 gemacht?** Dann sag: *„Übernimm die passenden Felder aus meiner Positionierung."* — Claude füllt Zielgruppe, Kernbotschaft und Vorschläge für Kategorien/Themen direkt aus `positionierung.md`.

> 👀 **Unsicher, wie das fertig aussieht?** Schau in `config/beispiel-ausgefuellt.md` — dort ist eine komplett ausgefüllte Config einer fiktiven Marke als Vorlage hinterlegt.

Das ist die einzige Datei, die deine Marke technisch definiert — alles andere bleibt unverändert.

---

## 9. `brand-voice.md` ausfüllen

Öffne `context/brand-voice.md` und beschreibe, **wie** deine Marke klingt: Tonalität, Anrede (Du/Sie), Tabus, 1–2 Referenzaccounts und ein paar Beispielsätze. Je konkreter, desto markentreuer schreibt Claude deine Captions. (Vieles davon ergibt sich schon aus deiner Positionierung.)

---

## 10. Automatik aktivieren — `/setup`

Jetzt der entscheidende Schritt: Die beiden automatischen Aufgaben (`karussell-wochenproduktion` Montags, `karussell-daily-posting` täglich) liegen im Paket nur als **Vorlagen** — sie laufen NICHT von allein. Du musst sie einmal registrieren.

**Das macht ein einziger Befehl.** Tipp in Claude Code:

```
/setup
```

Claude prüft deine Config, fragt dich nach den Zeiten und legt beide Aufgaben für dich an. Zeiten kannst du dabei frei wählen (z.B. „Wochenproduktion Sonntag 18 Uhr").

> ⚙️ **Cloud oder lokal?** `/setup` fragt dich, wie es laufen soll:
> - **Cloud (empfohlen):** läuft auf Servern — auch wenn dein Rechner aus ist. Verlässlich für „jeden Montag".
> - **Lokal:** läuft nur, wenn dein Rechner an und Claude Code offen ist. Gut zum Testen, riskant für festen Rhythmus.

---

## 11. Erster Testlauf

Bevor du auf den Automatik-Rhythmus wartest, mach einen Probelauf:

1. Sag: *„Führe die Wochenproduktion jetzt einmal testweise aus."*
2. Claude produziert die Karussells (auf Basis deiner Positionierung) und legt sie in `outputs/karussell-pipeline/zur-pruefung/` ab
3. Öffne die Markdown-Dateien, klick die Canva-Links an, prüfe Text & Design
4. **Freigeben:** Verschiebe die guten Dateien von `zur-pruefung/` nach `bereit-zum-posten/` (oder sag: *„Gib mir die KW-Karussells frei."*)
5. Der tägliche Posting-Task übernimmt sie von dort automatisch (bzw. zeigt sie im Hinweis-Modus an)

**Der Freigabe-Workflow in Kürze:**
`zur-pruefung/` (Claude produziert) → **du prüfst & verschiebst** → `bereit-zum-posten/` (Claude postet) → `gepostet/` (Archiv)

---

## 12. Fehlerbehebung & Fallstricke

| Problem | Lösung |
| --- | --- |
| Karussells wirken beliebig / treffen nicht | Wahrscheinlich ist `context/positionierung.md` noch leer. Hol Schritt 3 nach: *„Lass uns meine Positionierung erarbeiten."* |
| Text läuft im Design über den Rand | Claude kann die Schriftgröße per `format_text` anpassen — sag: *„Die Schrift auf Slide X ist zu groß, verkleinere sie."* Das System macht das normalerweise automatisch. |
| Designs sehen generisch aus, ohne mein Branding | Du hast vermutlich `generate-design` statt deines kopierten Templates genutzt. Das System muss IMMER dein Template per `copy-design` kopieren (siehe Schritt 4). |
| Mehrseitiges Template lässt sich nicht per Claude erstellen | Korrekt — Multi-Page-Templates baust du einmalig manuell in Canva (Schritt 4). Claude kopiert danach nur noch. |
| Posting passiert nicht | Prüfe, ob `blotato_account_id` in `brand-config.md` gesetzt ist (nicht mehr der Platzhalter). Ohne sie läuft nur der Hinweis-Modus. |
| Falsche Texte im Design | Prüfe, ob die Element-IDs in `brand-config.md` zu den richtigen Feldern gehören (Schritt 5 wiederholen). |

> Kommst du nicht weiter? Beschreib deinem Claude genau, was passiert ist — er hilft dir beim Debuggen. Du schaffst das. 💪

const http = require('http');
const fs = require('fs');
const path = require('path');
const dir = __dirname;
const port = 4001;
http.createServer((req, res) => {
  let file = path.join(dir, req.url === '/' ? 'START-HIER.html' : req.url);
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); res.end('Not found'); return; }
    const ext = path.extname(file);
    const types = { '.html': 'text/html', '.css': 'text/css', '.js': 'application/javascript' };
    res.writeHead(200, { 'Content-Type': types[ext] || 'text/plain' });
    res.end(data);
  });
}).listen(port);

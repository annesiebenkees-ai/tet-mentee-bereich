# Beispiel: So sieht eine fertig ausgefüllte brand-config.md aus

> ⚠️ **Das ist nur ein Beispiel zur Orientierung — KEINE echte Konfiguration.**
> Die fiktive Marke „Studio Nordlicht" (eine Branding-Coachin) zeigt dir, wie eine
> komplett ausgefüllte `brand-config.md` aussieht. Übernimm hier **nichts** direkt — die
> Canva-IDs, Element-IDs und die Blotato-ID sind erfunden und funktionieren bei dir nicht.
> Trag in deine echte `config/brand-config.md` deine eigenen Werte ein.

---

## Marke

```yaml
brand_name: "Studio Nordlicht"
instagram_handle: "studio.nordlicht"
instagram_niche: "Branding & Markenaufbau für Selbstständige"
```

---

## Canva

```yaml
canva_template_design_id: "DAFx7Kq2mNo"               # mein 4-seitiges Karussell-Template
canva_folder_id: "FAFa1bC2dE3"                        # Ordner "Nordlicht Produziert"
canva_posting_queue_folder_id: "FAFa4fG5hI6"          # Ordner "Nordlicht Posting Queue"
canva_gepostet_folder_id: "FAFa7jK8lM9"               # Ordner "Nordlicht Archiv"
```

---

## Template-Element-IDs

```yaml
slides_per_carousel: 4            # mein Template hat 4 Seiten

text_elements:
  - slide: 1
    rolle: "hook"
    element_id: "MAGxa1B2c3-LBd4E5f6G7"
  - slide: 1
    rolle: "cta"
    element_id: "MAGxa1B2c3-LBh8I9j0K1"
  - slide: 2
    rolle: "content"
    element_id: "MAGxl2M3n4-LBo5P6q7R8"
  - slide: 3
    rolle: "content"
    element_id: "MAGxs3N4o5-LBt6U7v8W9"
  - slide: 4
    rolle: "content"
    element_id: "MAGxx4O5p6-LBy7Z8a9B0"
```

---

## Blotato

```yaml
blotato_account_id: "blt_acct_8821xq"
```

---

## Posting

```yaml
posting_slots:
  - "07:30"
  - "17:00"
timezone: "Europe/Berlin"
carousels_per_week: 14          # 2 pro Tag
max_posts_per_run: 2
```

---

## Content-Kategorien

```yaml
kategorien:
  - name: "Markenstrategie"
    anteil: 6
    beschreibung: "Positionierung, Zielgruppe, Markenkern — was eine Marke unverwechselbar macht"
  - name: "Visuelle Identität"
    anteil: 4
    beschreibung: "Farben, Schriften, Logo, Bildwelt — Praxis-Tipps für ein stimmiges Erscheinungsbild"
  - name: "Behind-the-Scenes"
    anteil: 4
    beschreibung: "Einblicke in echte Branding-Projekte, Vorher/Nachher, ehrlicher Arbeitsalltag"
```

---

## Zielgruppe

```yaml
zielgruppe: "Selbstständige und kleine Unternehmerinnen (30–50), die spüren, dass ihr Auftritt nicht zu dem passt, was sie können — und eine Marke wollen, die ernst genommen wird."
kernbotschaft: "Eine starke Marke ist kein hübsches Logo, sondern Klarheit darüber, wofür du stehst — und der Mut, das sichtbar zu machen."
```

---

## Themen für Trendrecherche

```yaml
recherche_themen:
  - "Branding für Selbstständige"
  - "Markenaufbau Instagram"
  - "Personal Branding"
  - "visuelle Markenidentität"
```

# /setup — Automatik aktivieren

Dieser Befehl richtet die beiden wiederkehrenden Aufgaben des Karussell-Systems ein. **Ohne diesen Schritt produziert und postet nichts automatisch** — die `SKILL.md`-Dateien unter `.claude/scheduled-tasks/` sind nur Vorlagen und müssen als echte wiederkehrende Aufgaben registriert werden.

Wenn der Nutzer `/setup` ausführt, führe Folgendes aus:

## 1. Voraussetzungen prüfen

- Lies `config/brand-config.md`. Enthält sie noch Platzhalter (`[...]`) in Pflichtfeldern, brich ab und sag freundlich, welche Felder noch fehlen — Setup erst danach.
- Lies `context/positionierung.md`. Ist sie leer, weise darauf hin, dass die Karussells ohne Positionierung beliebig werden (empfehle „Lass uns meine Positionierung erarbeiten"), frag aber, ob trotzdem fortgefahren werden soll.

## 2. Ausführungsart wählen

Frag den Nutzer **einmal**, wie zuverlässig es laufen soll:

> Wie soll deine Automatik laufen?
> **[A] Cloud (empfohlen)** — läuft auf Servern, auch wenn dein Rechner aus ist. Verlässlich für „jeden Montag".
> **[B] Lokal** — läuft auf deinem Rechner; nur wenn Claude Code offen und der Rechner an ist.

Nutze je nach Wahl die passende Scheduling-/Routines-Funktion von Claude Code (Cloud-Routine bzw. lokaler Scheduled Task; z.B. über `create_scheduled_task`).

## 3. Zwei Aufgaben registrieren

Lege auf Basis der Vorlagen zwei wiederkehrende Aufgaben an. Die jeweilige `SKILL.md` enthält Zweck, Ablauf und das `cron`-Standardintervall — nutze es als Inhalt/Anweisung der Aufgabe, und übernimm Posting-Zeiten/Frequenz aus `config/brand-config.md`:

1. **Wochenproduktion** — Standard `cron: "0 8 * * 1"` (Montags). Anweisung der Aufgabe: „Öffne diesen Workspace und folge `.claude/scheduled-tasks/karussell-wochenproduktion/SKILL.md`."
2. **Daily-Posting** — Standard `cron: "0 9 * * *"` (täglich). Anweisung: „Öffne diesen Workspace und folge `.claude/scheduled-tasks/karussell-daily-posting/SKILL.md`."

Frag, ob die Standardzeiten passen, oder pass sie nach Wunsch an (z.B. „Wochenproduktion Sonntag 18 Uhr").

## 4. Bestätigen

Liste am Ende auf, welche Aufgaben mit welchem Zeitplan und welcher Ausführungsart (Cloud/Lokal) angelegt wurden. Weise bei **Lokal** darauf hin, dass der Rechner zur geplanten Zeit an und Claude Code offen sein muss. Erinnere daran, dass Posting erst aktiv wird, sobald `blotato_account_id` in der `brand-config.md` gesetzt ist (sonst Hinweis-Modus).

---
name: karussell-wochenproduktion
description: Produziert wöchentlich eine konfigurierbare Anzahl Instagram-Karussells aus dem eigenen Canva-Template und legt sie zur Prüfung ab
cron: "0 8 * * 1"   # Montags 08:00 — anpassbar (Minute Stunde Tag Monat Wochentag)
model: sonnet
---

# Karussell-Wochenproduktion

Dieser Task produziert wöchentlich neue Instagram-Karussells für deine Marke: Er recherchiert aktuelle Themen, plant die Posts nach deinen Content-Kategorien, kopiert dein Canva-Template, befüllt es mit Text und legt jedes Karussell als Markdown-Datei in `outputs/karussell-pipeline/zur-pruefung/` ab — bereit für deine Freigabe.

> **Generisches Template.** Dieser Task enthält KEINE markenspezifischen Werte. Alles, was deine Marke ausmacht, steht in `config/brand-config.md`. Diesen Task musst du nicht bearbeiten.

## Schritt 0: Konfiguration & Fundament laden

Lies `config/brand-config.md`. **Alle** Konfigurationswerte (Markenname, Handle, Canva-IDs, Element-IDs, Kategorien, Zielgruppe, Recherche-Themen, `carousels_per_week` usw.) stammen aus dieser Datei. Wenn Pflichtfelder noch Platzhalter (`[...]`) enthalten, brich ab und weise darauf hin, welche Felder fehlen.

Lies dann `context/positionierung.md` — **das Fundament**. Ist sie noch leer (Platzhalter), weise darauf hin, dass zuerst das Positionierungs-Interview (`reference/positionierung-interview.md`) laufen sollte, sonst werden die Karussells beliebig.

## Schreibregeln

- Echte Umlaute (ä, ö, ü, ß)
- Tonalität strikt nach `context/brand-voice.md`
- Jedes Karussell wurzelt in `context/positionierung.md` (Zielgruppe, innere Stimmen, Kernbotschaft) — nichts wird beliebig erfunden
- Konkrete Alltagsszenen statt abstrakter Floskeln
- Hook aus dem Cover wird in der Caption NICHT wiederholt (siehe `context/hook-framework.md`)
- Echter Mehrwert auf jeder Slide

## Ablauf

### 1. Kontext laden

- `config/brand-config.md` — alle Konfigurationswerte (siehe Schritt 0)
- `context/positionierung.md` — **das Fundament**: Wer/Warum/Werte, Zielgruppe, innere Stimmen, Kernbotschaft, Positionierungs-Statement
- `context/brand-voice.md` — Tonalität, Anrede, Tabus, Beispielsätze
- `context/hook-framework.md` — Hook-Kategorien & -Regel
- `context/caption-formeln.md` — die 5 Caption-Strukturen

### 2. Themen recherchieren

Leite Themen primär aus `positionierung.md` ab — vor allem aus den **inneren Stimmen / Content-Ideen** und der Kernbotschaft. Ergänze via WebSearch aktuelle Trends/Diskussionen zu den `recherche_themen` aus der Config sowie zum „Markt & Timing" der Positionierung. Sammle 5–10 relevante Aufhänger für die Woche.

### 3. Karussells planen

Plane `carousels_per_week` Karussells. Verteile sie über die Woche und über die `kategorien` aus der Config (gemäß den `anteil`-Werten). Mische die Reihenfolge, sodass nicht mehrere gleichartige Posts hintereinander kommen. Ordne jedem Karussell einen Posting-Tag und einen Slot aus `posting_slots` zu. Wähle pro Karussell eine **Hook-Kategorie** (rotierend) passend zur Zielgruppe aus der Positionierung.

### 4. Pro Karussell: Canva-Design aus Template kopieren und befüllen

Dein Basis-Template (`canva_template_design_id`) enthält dein echtes Branding (Logo, Farben, Schriften, ggf. Maskottchen/Foto). Für jedes geplante Karussell:

1. `copy-design` auf `canva_template_design_id` — erzeugt eine Kopie mit identischem Layout
2. `start-editing-transaction` auf die neue Kopie öffnen
3. Textelemente via `perform-editing-operations` ersetzen — pro Eintrag in `text_elements` aus der Config:
   - `rolle: hook` → Hook/Hauptaussage (nach `hook-framework.md`)
   - `rolle: cta` → Call-to-Action
   - `rolle: content` → Mehrwert-Text der jeweiligen Slide
   - Läuft Text über den Rahmen: per `format_text` die `font_size` reduzieren
   - `update_title` → aussagekräftiger Titel, z.B. „<Marke> KW<NR> - <Kategorie> - <Kurz-Slug>"
4. `commit-editing-transaction`
5. `move-item-to-folder` → `canva_folder_id`

### 5. Caption erstellen

Pro Karussell eine Caption nach `caption-formeln.md` (rotierend durch die 5 Formeln) + 5–10 passende Hashtags. Ton nach `brand-voice.md`. Hook aus dem Cover nicht wiederholen.

### 6. Output schreiben

Pro Karussell eine Markdown-Datei in `outputs/karussell-pipeline/zur-pruefung/`:

```
zur-pruefung/YYYY-MM-DD-<kategorie>-<kurzer-slug>.md
```

Inhalt:

```markdown
# <Titel>

**Kategorie:** <Kategorie aus der Config>
**Geplanter Posting-Slot:** <Datum> <Slot aus posting_slots> <timezone>

## Canva-Designs
- Cover: <design_id> — <edit_url>
- Slide 2: <design_id> — <edit_url>
- ...

## Caption
<Caption-Text inkl. Hashtags>
```

### 7. Abschluss

Liste am Ende alle erstellten Dateien und Canva-Design-Links auf, damit der Kunde sie in `zur-pruefung/` prüfen und nach Freigabe nach `bereit-zum-posten/` verschieben kann.

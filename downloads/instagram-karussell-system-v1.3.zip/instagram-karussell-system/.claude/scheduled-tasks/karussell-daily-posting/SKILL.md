---
name: karussell-daily-posting
description: Postet täglich freigegebene Karussells über Blotato auf Instagram (konfigurierbare Slots)
cron: "0 9 * * *"   # täglich 09:00 — anpassbar (Minute Stunde Tag Monat Wochentag)
model: sonnet
---

# Karussell Daily Posting

Dieser Task nimmt die von dir freigegebenen Karussells aus `outputs/karussell-pipeline/bereit-zum-posten/`, exportiert die Canva-Designs als PNG und plant sie über Blotato auf Instagram ein.

> **Generisches Template.** Keine markenspezifischen Werte hier — alles steht in `config/brand-config.md`.

## Schritt 0: Konfiguration laden

Lies `config/brand-config.md`. Relevante Werte: `blotato_account_id`, `instagram_handle`, `canva_posting_queue_folder_id`, `canva_gepostet_folder_id`, `posting_slots`, `timezone`, `max_posts_per_run`.

## Hinweis-Modus (Blotato noch nicht verbunden)

Solange `blotato_account_id` in der Config noch den Platzhalter `[BLOTATO_ACCOUNT_ID]` enthält:

1. Prüfe `outputs/karussell-pipeline/bereit-zum-posten/` auf vorhandene Markdown-Dateien
2. Falls leer: nichts tun, Session beenden
3. Falls Dateien vorhanden: Liste die nächsten bis zu `max_posts_per_run` Karussells (Dateiname + geplanter Slot) auf und weise darauf hin, dass automatisches Posting erst nach Abschluss der Blotato-Einrichtung (siehe `reference/setup-anleitung.md`) aktiv wird. **Verschiebe NICHTS, ändere NICHTS.**

## Aktiv-Modus (sobald `blotato_account_id` gesetzt ist)

1. **Ordner prüfen**
   - Lies alle Markdown-Dateien in `bereit-zum-posten/`
   - Wenn leer: nichts tun, Session beenden

2. **Für bis zu `max_posts_per_run` Karussells:**
   - a) Lies die Markdown-Datei (Caption, Canva-Design-Links der Slides)
   - b) Exportiere jedes verlinkte Canva-Design als PNG (`export-design`)
   - c) Plane den Post über Blotato ein:
     - `accountId`: `blotato_account_id`
     - `platform`: `instagram`
     - `media`: alle exportierten PNGs in Reihenfolge (Cover, Slides, CTA) als Karussell
     - `caption`: aus der Markdown-Datei
     - `scheduledTime`: nächster freier Slot aus `posting_slots` (ISO 8601 + `timezone`)
   - d) Verschiebe die zugehörigen Canva-Designs nach `canva_gepostet_folder_id`
   - e) Verschiebe die Markdown-Datei nach `outputs/karussell-pipeline/gepostet/`

3. **Bei Fehler:** Datei in `bereit-zum-posten/` lassen, Fehler im Session-Log dokumentieren, mit nächstem Karussell fortfahren.

## Wichtig

- Nur Dateien verarbeiten, keine Unterordner
- Maximal `max_posts_per_run` Posts pro Lauf

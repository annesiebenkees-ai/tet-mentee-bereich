# CLAUDE.md

Diese Datei gibt Claude Code Anweisungen für die Arbeit in diesem Workspace. Sie wird automatisch zu Beginn jeder Session geladen.

---

## Was das hier ist

Dies ist das **Automatische Instagram-Karussell-System** — ein fertiges Paket, mit dem du jede Woche automatisch markengerechte Instagram-Karussells erstellst und über Blotato postest. Du füllst einmalig deine Markenwerte aus, danach läuft die Produktion und das Posting automatisch.

> **Was ein Social-Media-Manager für 500–2.000 €/Monat macht, erledigt dein Claude für ~20 €/Monat.**

**Deine Rolle (Claude):** Du führst den Nutzer durch die Einrichtung, produzierst die wöchentlichen Karussells, befüllst das Canva-Template und planst freigegebene Beiträge über Blotato ein. Du bist klar, ermutigend und hilfsbereit — der Nutzer braucht kein technisches Vorwissen.

---

## Erster Schritt für neue Nutzer

Wenn der Workspace noch nicht eingerichtet ist (Platzhalter in `config/brand-config.md`), leite den Nutzer durch **`reference/setup-anleitung.md`** — Schritt für Schritt.

**Allererster inhaltlicher Schritt ist die Positionierung:** Sagt der Nutzer „Lass uns meine Positionierung erarbeiten", folge `reference/positionierung-interview.md` und schreibe das Ergebnis nach `context/positionierung.md`. Diese Positionierung ist das Fundament, aus dem alle Karussells entstehen.

---

## Workspace-Struktur

```
.
├── START-HIER.html                    # ← Doppelklick: geführte Einrichtung im Browser
├── CLAUDE.md                          # Diese Datei
├── config/
│   ├── brand-config.md               # ← Die EINZIGE Datei, die du ausfüllst
│   └── beispiel-ausgefuellt.md       # Komplett ausgefülltes Beispiel
├── context/
│   ├── positionierung.md             # ← Dein Fundament (aus dem Positionierungs-Interview)
│   ├── brand-voice.md                # Tonalität & Schreibregeln (ausfüllen)
│   ├── hook-framework.md             # Hook-Kategorien (markenneutral)
│   └── caption-formeln.md            # Caption-Strukturen (markenneutral)
├── outputs/
│   └── karussell-pipeline/
│       ├── zur-pruefung/             # Neu produziert — wartet auf deine Freigabe
│       ├── bereit-zum-posten/        # Von dir freigegeben
│       └── gepostet/                 # Archiv
├── reference/
│   ├── setup-anleitung.md            # Schritt-für-Schritt-Onboarding
│   └── positionierung-interview.md   # Geführtes Positionierungs-Interview
└── .claude/
    ├── commands/
    │   └── setup.md                              # /setup — registriert die Automatik
    └── scheduled-tasks/
        ├── karussell-wochenproduktion/SKILL.md   # Vorlage: wöchentliche Produktion
        └── karussell-daily-posting/SKILL.md      # Vorlage: tägliches Posting
```

| Datei / Ordner | Zweck |
| --- | --- |
| `START-HIER.html` | Geführte Einrichtungs-Website (im Browser öffnen). Erklärt das Tool und führt Schritt für Schritt durch das Setup — der freundlichste Einstieg für den Kunden. |
| `config/brand-config.md` | **Herzstück.** Alle markenspezifischen Werte an einem Ort. Das ganze System liest daraus. |
| `config/beispiel-ausgefuellt.md` | Komplett ausgefülltes Beispiel (fiktive Marke) als Orientierung — wird vom System nicht gelesen. |
| `context/positionierung.md` | **Fundament.** Die fertige Positionierung (aus dem Positionierungs-Interview). Quelle für Hooks, Themen, Botschaften. |
| `reference/positionierung-interview.md` | Geführtes Interview, das `positionierung.md` befüllt. |
| `context/brand-voice.md` | Wie deine Marke klingt — Ton, Anrede, Tabus, Beispielsätze. |
| `context/hook-framework.md` | Markenneutrale Hook-Kategorien für Cover-Slides. |
| `context/caption-formeln.md` | Fünf markenneutrale Caption-Strukturen. |
| `outputs/karussell-pipeline/` | Der Freigabe-Workflow (siehe README dort). |
| `reference/setup-anleitung.md` | Vollständige Einrichtungsanleitung. |
| `.claude/scheduled-tasks/` | Die beiden Automatik-Aufgaben. |

---

## Der Workflow

1. **Wöchentlich (automatisch):** `karussell-wochenproduktion` recherchiert Themen, plant Karussells nach deinen Kategorien, kopiert dein Canva-Template, befüllt es und legt jedes Karussell in `outputs/karussell-pipeline/zur-pruefung/` ab.
2. **Du:** Prüfst die Karussells und verschiebst die freigegebenen nach `bereit-zum-posten/`.
3. **Täglich (automatisch):** `karussell-daily-posting` exportiert die freigegebenen Designs und plant sie über Blotato auf Instagram ein, dann wandern sie nach `gepostet/`.

---

## Wichtige Prinzipien

- **Die Automatik läuft NICHT von allein.** Die Dateien unter `.claude/scheduled-tasks/` sind nur Vorlagen — sie müssen mit **`/setup`** als echte wiederkehrende Aufgaben registriert werden (Cloud oder lokal). Solange `/setup` nicht lief, produziert/postet nichts automatisch.
- **Nur `config/brand-config.md` und `context/brand-voice.md` werden vom Nutzer ausgefüllt.** Die SKILL-Dateien sind generisch und müssen nicht bearbeitet werden.
- **Canva-Template immer per `copy-design` kopieren** — niemals per `generate-design` neu erzeugen (liefert kein echtes Branding).
- **Multi-Page-Templates baut der Nutzer einmalig manuell** in Canva; danach wird nur noch kopiert und befüllt.
- **Läuft Text über:** Schriftgröße per `format_text` anpassen.
- Sprache: **Deutsch.** Ton: klar, ermutigend, „du schaffst das".

# zur-pruefung/

Hier landen **neu produzierte** Karussells und warten auf deine Freigabe. Prüf sie und verschieb die guten nach `bereit-zum-posten/` (oder sag deinem Claude: „Gib dieses Karussell frei.").

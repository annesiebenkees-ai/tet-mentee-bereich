# Karussell-Pipeline

Der Freigabe-Workflow für deine Instagram-Karussells. Drei Ordner, eine klare Richtung:

```
zur-pruefung/  →  bereit-zum-posten/  →  gepostet/
  (Claude          (du gibst frei)        (Archiv)
  produziert)
```

| Ordner | Wer befüllt | Wer leert |
| --- | --- | --- |
| `zur-pruefung/` | `karussell-wochenproduktion` (wöchentlich) | **du** — verschieb freigegebene Karussells nach `bereit-zum-posten/` |
| `bereit-zum-posten/` | du (durch Freigabe) | `karussell-daily-posting` (täglich) |
| `gepostet/` | `karussell-daily-posting` (nach dem Posten) | — (Archiv, bleibt liegen) |

## So gibst du frei

1. Öffne eine Markdown-Datei in `zur-pruefung/`
2. Klick die Canva-Links an, prüfe Text und Design
3. Passt es? Verschieb die Datei nach `bereit-zum-posten/` (oder sag deinem Claude: *„Gib dieses Karussell frei."*)
4. Den Rest erledigt der tägliche Posting-Task

> Jede Datei steht für **ein** Karussell und enthält Titel, Kategorie, geplanten Slot, die Canva-Design-Links und die fertige Caption.

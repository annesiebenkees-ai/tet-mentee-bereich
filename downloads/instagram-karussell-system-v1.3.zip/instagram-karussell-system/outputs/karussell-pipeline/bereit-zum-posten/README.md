# bereit-zum-posten/

**Von dir freigegebene** Karussells. Der tägliche Posting-Task greift sie hier ab und plant sie ein — danach wandern sie automatisch nach `gepostet/`.

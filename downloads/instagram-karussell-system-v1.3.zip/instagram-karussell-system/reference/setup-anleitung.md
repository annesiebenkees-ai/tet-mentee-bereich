# Setup-Anleitung: Dein automatisches Instagram-Karussell-System

Willkommen! 🎉 In dieser Anleitung richtest du Schritt für Schritt dein eigenes Karussell-System ein. **Du brauchst kein technisches Vorwissen.** Dein Claude führt dich durch jeden Schritt — wenn du irgendwo nicht weiterkommst, schreib einfach: *„Hilf mir bei Schritt X der Setup-Anleitung."*

Plane einmalig ca. **1,5–2 Stunden** für die Einrichtung ein (inkl. Positionierung). Danach läuft alles automatisch.

---

## 0. Was du hier bekommst

Ein System, das **jede Woche automatisch** Instagram-Karussells für deine Marke produziert — in deinem Branding, mit recherchierten Themen und fertigen Captions, die auf deiner echten Positionierung aufbauen. Du prüfst sie nur noch kurz und gibst sie frei, der Rest wird automatisch auf Instagram eingeplant.

> **Was ein Social-Media-Manager für 500–2.000 €/Monat macht, erledigt dein Claude für ~20 €/Monat.**

So läuft es nach dem Setup:
- **Wöchentlich:** Claude recherchiert, erstellt deine Karussells und legt sie in `zur-pruefung/` ab
- **Du:** Schaust drüber, verschiebst die guten nach `bereit-zum-posten/`
- **Täglich:** Claude exportiert und plant die freigegebenen Karussells über Blotato auf Instagram ein

---

## 1. Voraussetzungen

Du brauchst:

- ✅ **Claude Code** (installiert und eingerichtet) — die App, in der du das hier liest
- ✅ Einen **Canva-Account** (Pro empfohlen, damit du eigene Schriften/Marken nutzen kannst)
- ✅ Einen **Blotato-Account** (für das automatische Posten auf Instagram) — [blotato.com](https://blotato.com)
- ✅ Deinen **Instagram-Account** (am besten ein Business- oder Creator-Account)

---

## 2. MCP-Server verbinden (Canva + Blotato)

„MCP-Server" sind die Brücken, über die dein Claude mit Canva und Blotato spricht.

1. Öffne in Claude Code die **Einstellungen → MCP Servers**
2. Füge den **Canva**-Server hinzu (folge dem Verbindungs-Dialog, du wirst einmalig bei Canva eingeloggt)
3. Füge den **Blotato**-Server hinzu (ebenso)
4. Teste die Verbindung — sag deinem Claude: *„Liste meine Canva-Ordner auf."* Wenn eine Liste kommt, funktioniert Canva. ✅

> Klappt eine Verbindung nicht? Sag: *„Der Canva-MCP-Server verbindet nicht — hilf mir."*

---

## 3. Deine Positionierung 🔥 (das Fundament)

**Das ist der wichtigste inhaltliche Schritt** — und der Grund, warum deine Karussells später wirklich treffen statt beliebig zu sein. Bevor wir Design und Technik anfassen, klären wir, *wofür* du stehst und *wen* du erreichst.

1. Sag deinem Claude: *„Lass uns meine Positionierung erarbeiten."*
2. Er führt dich durch ein kurzes Interview — entweder 9 Fragen von Grund auf (ca. 20–30 Min.) oder über deinen Freitext, wenn du schon etwas hast.
3. Am Ende steht deine fertige Positionierung in `context/positionierung.md` — das Fundament für jeden Hook und jede Botschaft.

> 💡 Dieser Schritt spart dir später Arbeit: Aus deiner Positionierung kann Claude die Zielgruppe, Kernbotschaft und sogar Content-Kategorien für die `brand-config.md` direkt ableiten.

---

## 4. Dein Canva-Template einmalig bauen

Der wichtigste manuelle Schritt — und du machst ihn nur **ein einziges Mal**.

1. Erstelle in Canva ein neues **Instagram-Karussell** (Format 1080 × 1350 px, hochkant)
2. Baue **3–7 Seiten** mit deinem echten Branding: Logo, Farben, Schriften, ggf. Maskottchen oder Foto
3. Auf jede Seite kommt ein **Platzhalter-Textfeld** dort, wo später der wechselnde Text steht:
   - Seite 1: ein großes Feld für den **Hook** + ein kleines für den **CTA**
   - Folgeseiten: je ein Feld für den **Inhalt/Mehrwert**
   - Schreib zum Test irgendetwas rein, z.B. „Hier steht der Hook"

> ⚠️ **Wichtig — nicht von Claude generieren lassen.** Lass das Template NICHT über `generate-design` erstellen. Das liefert nur generische, farbige Designs ohne dein echtes Branding. Multi-Page-Templates mit deinem Branding müssen **einmalig manuell in Canva** gebaut werden. Danach kann Claude es beliebig oft kopieren und befüllen.

---

## 5. Claude richtet den Rest ein

Ordner anlegen, IDs raussuchen, Einstellungen eintragen — das machst du **nicht von Hand**.

**Erst die Ordner:**

> *„Leg mir in Canva vier Ordner an: Vorlage, Produzierte Karussells, Freigabe, Gepostet."*

**Dann zieh deine fertige Vorlage in den Ordner „Vorlage"** — ein Klick in Canva. Damit weiß Claude, welches Design deine Vorlage ist.

**Und dann der Satz, der alles Übrige erledigt:**

> *„Meine Karussell-Vorlage liegt jetzt im Ordner Vorlage. Hol dir von dort die Design-ID, lies die Element-IDs meiner Textfelder aus und trag alles in die `brand-config.md` ein — zusammen mit den Ordner-IDs und den passenden Feldern aus meiner Positionierung. Setz `carousels_per_week` erstmal auf 2."*

> 💡 **Warum `carousels_per_week` auf 2?** Für den ersten Testlauf reichen zwei Karussells. So siehst du in wenigen Minuten ein Ergebnis, statt eine ganze Woche produzieren zu lassen. Hochstellen kannst du später jederzeit.

> ⚠️ **Falls Claude nach der Design-ID fragt:** Die steht in der Canva-URL, wenn deine Vorlage offen ist — `canva.com/design/`**`DAF…xyz`**`/edit`. Den fetten Teil kopieren und ihm geben.

Danach steht in `config/brand-config.md` alles, was das System braucht. Schau ruhig einmal rein — verstehen musst du die Werte nicht, aber es beruhigt zu sehen, dass da nichts Magisches passiert. Als Orientierung liegt in `config/beispiel-ausgefuellt.md` eine komplett ausgefüllte Beispiel-Config.

---

## 6. `brand-voice.md` ausfüllen

Öffne `context/brand-voice.md` und beschreibe, **wie** deine Marke klingt: Tonalität, Anrede (Du/Sie), Tabus, 1–2 Referenzaccounts und ein paar Beispielsätze. Je konkreter, desto markentreuer schreibt Claude deine Captions. Oder lass dich fragen:

> *„Fülle jetzt bitte auch `context/brand-voice.md` aus — frag mich, was du dafür brauchst."*

---

## 7. Blotato verbinden + accountId eintragen

1. Verknüpfe in [Blotato](https://blotato.com) deinen Instagram-Account
2. Sag deinem Claude: *„Zeige mir meine verbundenen Blotato-Accounts."*
3. Notiere die **accountId** für deinen Instagram-Account

> Blotato noch nicht startklar? Kein Problem — du kannst alles andere schon einrichten. Solange die `blotato_account_id` leer bleibt, läuft das Posting im **Hinweis-Modus**: Claude zeigt dir dann nur an, was bereit wäre, postet aber noch nichts.

---

## 8. Automatik aktivieren — `/setup`

Jetzt der entscheidende Schritt: Die beiden automatischen Aufgaben (`karussell-wochenproduktion` Montags, `karussell-daily-posting` täglich) liegen im Paket nur als **Vorlagen** — sie laufen NICHT von allein. Du musst sie einmal registrieren.

**Das macht ein einziger Befehl.** Tipp in Claude Code:

```
/setup
```

Claude prüft deine Config, fragt dich nach den Zeiten und legt beide Aufgaben für dich an. Zeiten kannst du dabei frei wählen (z.B. „Wochenproduktion Sonntag 18 Uhr").

> 💬 **Falls Claude mit `/setup` nichts anfangen kann**, sag ihm stattdessen einfach das hier — das geht immer:
> *„Leg die beiden Aufgaben aus `.claude/scheduled-tasks/` als wiederkehrende Routinen an — Wochenproduktion montags, Posting täglich."*

> ⚙️ **Cloud oder lokal?** `/setup` fragt dich, wie es laufen soll:
> - **Cloud (empfohlen):** läuft auf Servern — auch wenn dein Rechner aus ist. Verlässlich für „jeden Montag".
> - **Lokal:** läuft nur, wenn dein Rechner an und Claude Code offen ist. Gut zum Testen, riskant für festen Rhythmus.

---

## 9. Erster Testlauf

Bevor du auf den Automatik-Rhythmus wartest, mach einen Probelauf:

1. Sag: *„Führe die Wochenproduktion jetzt einmal testweise aus."*
2. Claude produziert die Karussells (auf Basis deiner Positionierung) und legt sie in `outputs/karussell-pipeline/zur-pruefung/` ab
3. Öffne die Markdown-Dateien, klick die Canva-Links an, prüfe Text & Design
4. **Freigeben:** Verschiebe die guten Dateien von `zur-pruefung/` nach `bereit-zum-posten/` (oder sag: *„Gib mir die KW-Karussells frei."*)
5. Der tägliche Posting-Task übernimmt sie von dort automatisch (bzw. zeigt sie im Hinweis-Modus an)

**Der Freigabe-Workflow in Kürze:**
`zur-pruefung/` (Claude produziert) → **du prüfst & verschiebst** → `bereit-zum-posten/` (Claude postet) → `gepostet/` (Archiv)

---

## 10. Fehlerbehebung & Fallstricke

| Problem | Lösung |
| --- | --- |
| Karussells wirken beliebig / treffen nicht | Wahrscheinlich ist `context/positionierung.md` noch leer. Hol Schritt 3 nach: *„Lass uns meine Positionierung erarbeiten."* |
| Text läuft im Design über den Rand | Claude kann die Schriftgröße per `format_text` anpassen — sag: *„Die Schrift auf Slide X ist zu groß, verkleinere sie."* Das System macht das normalerweise automatisch. |
| `/setup` bewirkt nichts | Sag stattdessen: *„Leg die beiden Aufgaben aus `.claude/scheduled-tasks/` als wiederkehrende Routinen an — Wochenproduktion montags, Posting täglich."* |
| Designs sehen generisch aus, ohne mein Branding | Du hast vermutlich `generate-design` statt deines kopierten Templates genutzt. Das System muss IMMER dein Template per `copy-design` kopieren (siehe Schritt 4). |
| Mehrseitiges Template lässt sich nicht per Claude erstellen | Korrekt — Multi-Page-Templates baust du einmalig manuell in Canva (Schritt 4). Claude kopiert danach nur noch. |
| Posting passiert nicht | Prüfe, ob `blotato_account_id` in `brand-config.md` gesetzt ist (nicht mehr der Platzhalter). Ohne sie läuft nur der Hinweis-Modus. |
| Falsche Texte im Design | Die Element-IDs sind vertauscht. Sag: „Prüf die Zuordnung der Element-IDs in der `brand-config.md` nochmal gegen mein Template." |

> Kommst du nicht weiter? Beschreib deinem Claude genau, was passiert ist — er hilft dir beim Debuggen. Du schaffst das. 💪

# Positionierung

> **Das Fundament deiner Marke** — die Quelle, aus der das Karussell-System Hooks, Themen und Botschaften ableitet.
>
> Diese Datei entsteht im **Positionierungs-Interview** — sag deinem Claude: *„Lass uns meine Positionierung
> erarbeiten."* Er füllt sie dann gemeinsam mit dir aus. Du kannst sie auch selbst befüllen, wenn du deine
> Positionierung schon kennst.

---

## Wer du bist
[3–5 Sätze. Kraftvoll, unverwechselbar — deine Geschichte, nicht dein Beruf.]

## Dein Warum
[2–4 Sätze. Emotional, mit dem „Weil".]

## Was du ausstrahlst
[3–5 Sätze. Kernbotschaft und Werte.]

## Für wen du leuchtest
[3–4 Sätze. Deine Zielgruppe als echter Mensch — inkl. der stillen inneren Fragen, die sie laut nie ausspricht.]

## Was dich authentisch macht
[2–3 Sätze. Deine eigenen Hindernisse als Glaubwürdigkeit.]

## Wo du anders bist
[2–3 Sätze. Deine Lücke, deine Einzigartigkeit.]

## Dein Markt & Timing
[2–3 Sätze. Aktuelle Themen in deiner Branche, die dir nützen, + deine Haltung.]

## Content-Ideen aus inneren Stimmen
[3–5 konkrete Content-Impulse, die aus den Zweifeln/Blockaden deiner Zielgruppe entstehen.]
- …
- …
- …

## Dein Angebot in Position
[2–3 Sätze. Was du anbietest und warum Angebot + Positionierung zusammenpassen.]

---

## 🎯 Positionierungs-Statement (Elevator Pitch)

> [2–3 Sätze, in Ich-Form, klar und emotional. So persönlich, dass es auf niemand anderen zutrifft. In 30 Sekunden verständlich.]

# Brand Voice

> Hier definierst du, **wie** deine Marke klingt. Während `config/brand-config.md` die harten Fakten enthält
> (Namen, IDs, Zahlen), legt diese Datei den Ton fest, in dem Claude deine Karussells und Captions schreibt.
> Fülle die Platzhalter aus — je konkreter, desto markentreuer schreibt Claude.

---

## Tonalität

> 3–5 Adjektive, die deine Stimme beschreiben. Denk an: Wie würde eine gute Freundin / ein Experte deiner
> Nische sprechen?

- [z.B. direkt]
- [z.B. ermutigend]
- [z.B. nahbar]
- [z.B. fundiert]

In einem Satz: **„Meine Marke klingt wie [...]."**

---

## Anrede & Stil

```yaml
anrede: "[Du / Sie]"                       # Sprichst du deine Community per Du oder Sie an?
emojis: "[sparsam / gar nicht / viel]"     # Wie viele Emojis passen zu dir?
satzlaenge: "[kurz & knackig / variabel]"  # Kurze Sätze oder ausführlicher?
perspektive: "[Ich / Wir]"                 # Schreibst du aus Ich- oder Wir-Perspektive?
```

---

## Schreibregeln

- Echte Umlaute verwenden (ä, ö, ü, ß) — keine Umschreibungen (ae, oe, ue)
- [Weitere Regel, z.B. „Keine Fachbegriffe ohne Erklärung"]
- [Weitere Regel, z.B. „Immer konkreter Mehrwert, keine leeren Floskeln"]
- [Weitere Regel]

---

## Was wir NIE sagen (Tabus)

> Wörter, Themen oder Tonlagen, die nicht zu deiner Marke passen.

- [z.B. keine Angstmache / kein Druck]
- [z.B. keine unrealistischen Versprechen]
- [z.B. bestimmte Themen, die du meidest]

---

## Referenzaccounts

> 1–3 Instagram-Accounts, deren Tonalität dir gefällt (zur Orientierung, nicht zum Kopieren).

- [@account_1] — [was dir daran gefällt]
- [@account_2] — [...]

---

## Beispielsätze

> Hilft Claude enorm. Schreib je 1–2 Sätze, die „typisch deine Marke" klingen — und 1–2, die es NICHT tun.

**So klingen wir (gut):**
- "[Beispielsatz]"
- "[Beispielsatz]"

**So klingen wir NICHT (schlecht):**
- "[Gegenbeispiel]"
- "[Gegenbeispiel]"

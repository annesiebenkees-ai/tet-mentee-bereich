# Hook-Framework

Vier Hook-Kategorien für die Cover-Slides deiner Instagram-Karussells. Markenneutral — die Platzhalter werden mit deinen Inhalten gefüllt (Stimme aus `context/brand-voice.md`, Substanz aus `context/positionierung.md`).

## Zahlen-Hooks

"Ich mache [Zahl] im Monat — mit [Detail]."

## Anleitungs-Hooks

"Die exakte [Strategie] hinter meinen [Ergebnis]:"

## Provokante Hooks

"Du brauchst keine [was alle denken]. Du brauchst [was hilft]."

## Neugier-Hooks

"Was ich an einem [Tag] mache, der später [Ergebnis] bringt:"

**Regel:** Der Hook aus dem Cover wird in der Caption NICHT wiederholt.

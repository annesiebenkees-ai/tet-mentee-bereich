# Caption-Formeln

Fünf bewährte Caption-Strukturen für Instagram-Karussells. Markenneutral — bei Anwendung mit deiner Brand Voice (siehe `context/brand-voice.md`) füllen.

## Formel 1: Provokante Behauptung + Beweis

```
[Starke Aussage mit Zahl]
Die meisten denken, das geht nicht. Geht es aber.
[1-2 Sätze Kontext]
[Punkt 1], [Punkt 2], [Punkt 3]
Das ist kein Zufall. Das ist System.
[CTA]
```

## Formel 2: Schritt-für-Schritt Anleitung

```
So [Ergebnis] in [Zeitraum]:
Schritt 1-5: [Aktionen]
Das ist alles. Kein Geheimnis, nur Umsetzung.
[CTA]
```

## Formel 3: Kontrast (Vorher / Nachher)

```
Vorher: [Zustand/Glaubenssatz]
Nachher: [Zustand/Ergebnis]
Der Unterschied? [Kernaussage]
[1-2 Sätze Erklärung]
[CTA]
```

## Formel 4: Storytelling (kurz)

```
[Kurze persönliche Anekdote, 2-4 Sätze]
[Wendepunkt / Erkenntnis]
[Verbindung zur Kernbotschaft]
[CTA]
```

## Formel 5: Liste / Listicle

```
[Anzahl] [Dinge/Tipps/Fehler] zu [Thema]:
1. [Punkt]
2. [Punkt]
3. [Punkt]
...
[Abschlusssatz mit Kernbotschaft]
[CTA]
```

## CTA-Varianten

- **Saves:** "Speicher dir das, du wirst es brauchen."
- **Kommentare:** "Kommentiere [KEYWORD]"
- **DM:** "Schreib mir [KEYWORD]"
- **Link in Bio / Shares / Folgen**

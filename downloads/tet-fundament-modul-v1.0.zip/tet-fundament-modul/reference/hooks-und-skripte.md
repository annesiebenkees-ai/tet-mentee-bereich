# Hooks & Skripte — die ersten 3 Sekunden entscheiden

> Hintergrund-Methode für `/content-saeulen`. Menschen entscheiden in **einer** Sekunde, ob sie bleiben.
> Die Hook ist nicht der Anfang deines Videos — die Hook IST das Video. Alles andere ist Erklärung.

## Die 5 Hook-Strategien

| Strategie | So funktioniert sie | Muster / Beispiel |
| --- | --- | --- |
| **Neugier** | Öffnet eine Lücke, die der Zuschauer schließen will | „Was würde passieren, wenn …" — mit konkreter Alltagsnuance |
| **Schock** (Bild-Zeitung) | Deckt eine Ursache/Folge auf, die niemand gesehen hat | Sprich über das, was **unter** der Erde liegt (Wurzeln), nicht über das Offensichtliche |
| **Kontrovers** | Klare Haltung, die nicht jeder teilt → Reaktion | „Du wirst es nicht mögen, aber …" / „Es tut mir leid, dir das zu sagen, aber …" |
| **Vertrauen** (Spiegelung) | Der Zuschauer fühlt sich erkannt | „Du bist nicht die Einzige, die …" + ein Gedanke, den man nie laut ausspricht |
| **Gegenteilige Emotion** | Die Emotion nach dem ersten Satz ist das Gegenteil des Erwarteten | „Mein Chef hat mich entlassen. Ich fand's geil." → erzeugt sofort die Frage *Warum?* |

**Schlechte Hooks (verboten):** „Heute zeige ich dir …", „Hast du gewusst, dass …", „Hier sind 3 Tipps …" — jede Form von Ankündigung.

## Schreib-Prinzipien

- **Show, don't tell.** Zeig die Szene, erkläre nicht die Emotion. Nicht „Sie war überfordert", sondern: „Sie sitzt am Küchentisch, das Kind schreit, das Handy klingelt — und denkt: Ich kann nicht mehr."
- **Konkret statt abstrakt.** Überbegriffe sind, was eine Maschine schreibt. Konkrete Szenen holst du aus dem echten Leben.
- **Gegenwart statt Vergangenheit.** „Ich sitze im Auto, 0 € auf dem Konto, und denke …" zieht stärker als „Damals hatte ich …".
- **Echte Sprache.** Wie ein Mensch spricht, nicht wie ein Referat.

## Der Skript-Aufbau (30–45-Sek-Reel)

| Abschnitt | Zeit | Inhalt |
| --- | --- | --- |
| **HOOK** | Sek 1–3 | Erster Satz, wortwörtlich geplant. Aus Wurzel/Ast. Eine der 5 Strategien. |
| **SZENE** | Sek 4–20 | Konkreter Alltagsmoment, in der Gegenwart, mit innerem Gedanken + körperlicher Emotion. Kein Erklären. |
| **WURZEL/WENDUNG** | Sek 21–35 | Eine Ursache, die niemand gesehen hat. Kein Tipp — eine Erkenntnis. |
| **BOGEN** | Sek 36–45 | Von der Einstiegs-Emotion zur Hoffnung — als konkrete Szene. |
| **CTA** | Sek 45–50 | Ein Satz, spezifisch, passend zum Angebot. (Ein CTA am Anfang tötet die Watchtime.) |

## Storytelling-Strukturen (zur Auswahl)

Dreiakter (Setup–Konflikt–Lösung) · Vorher–Nachher–Brücke · Ranking (mit Meinung) · Pitch (Problem–Lösung–Erklärung) · Vergleich (A vs. B) · Abenteuer (Teaser–Erkunden–offenes Ende).

## Qualitäts-Check vor dem Posten

- Trifft die Hook wirklich, oder klingt sie nur nett?
- Bin ich sofort in der Szene, oder erkläre ich noch?
- Erzähle ich in der Gegenwart?
- Habe ich einen Gedanken auf Ebene 2/3 eingebaut?
- Endet es mit Hoffnung als konkreter Szene?

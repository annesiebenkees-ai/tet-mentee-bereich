# Stages & die 5 Content-Säulen

> Hintergrund-Methode für `/content-saeulen`. Hier wird aus dem Fundament (Positionierung) ein
> funktionierendes Content-System. **Warum es ohne Säulen nicht hält:** Ein Fundament ohne Säulen
> ist ein Haus ohne tragende Wände — es sieht von außen gut aus und fällt beim ersten Sturm zusammen.

## 👥 Die 3 Zielgruppen-Stages — wen du gerade abholst

| Stage | Zustand | Was sie braucht | Prinzip |
| --- | --- | --- | --- |
| **Unaware** | weiß nicht, dass ein Problem existiert | Alltagsszenen, Identifikation, Humor — keine Tipps | Du bist nicht der Held, du bist der **Spiegel** |
| **Problem Aware** | kennt das Problem, sucht | das Problem besser beschrieben, als sie es könnten; Lösung als Hinweis | **Cowboy am Lagerfeuer** — von Mensch zu Mensch |
| **Consideration** | vergleicht, kurz vor Kauf | Philosophie, konkrete Abläufe, echte Geschichten, Klarheit übers Angebot | Zeig, **was du nicht bist** — das schafft Vertrauen |

Verteile die Woche über die Stages — nicht alles für Kaufbereite, nicht alles für Fremde.

## 🏛️ Die 5 Content-Säulen

Jeder funktionierende Account bedient regelmäßig alle fünf. Jede Säule hat ihre Aufgabe — nicht jeder Post muss viral gehen.

1. **Expertise** — dein Wissen, Tipps, Frameworks; zeigen, dass du weißt, wovon du sprichst. *Ziel: Vertrauen, zeigen dass du Antworten hast.* → Problem Aware
2. **Mensch** — wer du bist, was du erlebt hast, deine Fehler, was dich nachts wachhielt und wie du da rauskamst. *Ziel: Verbindung & Identifikation.* → Unaware
3. **Social Proof** — kein nacktes Ergebnis, sondern eine Kunden-Reise; Auftritte, Kooperationen, Meinungen, für die du bekannt bist. *Ziel: Vertrauen stärken.* → Consideration
4. **Lifestyle** — die Situationen, die deine Zuschauer täglich erleben, in ihren eigenen Gedanken-Worten. *Ziel: Nähe, das Feuer zum Menschen bringen.* → Unaware
5. **Angebot** — was du konkret anbietest, was jemand bekommt, wie der Prozess aussieht, was sich danach ändert. *Ziel: Sichtbarkeit fürs Angebot, nächsten Schritt klar machen.* → Consideration

## 🎡 Das Emotionsrad — Gefühle präzise treffen

Wähle nie eine Grundemotion („Angst"), sondern die **innere Ebene**: „das Gefühl, nie gut genug zu sein."
- **Einstiegs-Emotion:** spezifische Unterkategorie, körperlich beschrieben.
- **Abschluss-Emotion:** immer **Hoffnung** — als konkrete Szene, nie als Kalenderspruch.

**Drei Ebenen von Gedanken** (je tiefer, desto stärker): (1) was sie der besten Freundin erzählen, (2) was sie ins Tagebuch schreiben, (3) **der Therapie-Gedanke** — was sie sich nicht laut zu sagen trauen. ← der stärkste Content trifft hier.

## Wochen-Mischung (Richtwert)

Pro Woche so verteilen, dass **Reichweite UND Verkauf** bedient werden — z. B.:
- Säulen Mensch/Lifestyle (Unaware) für Reichweite,
- Expertise (Problem Aware) für Vertrauen,
- Social Proof/Angebot (Consideration) mind. **1× pro Woche** für Verkauf.

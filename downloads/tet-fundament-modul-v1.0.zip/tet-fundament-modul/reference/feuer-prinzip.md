# Das Feuer-Prinzip — Positionierung, die niemand kopieren kann

> Hintergrund-Methode für den Befehl `/positionierung`. Du bist das Feuer. Deine Zielgruppe sind die Menschen,
> die zu deinem Feuer kommen. Deine Aufgabe ist nicht, jedem zu gefallen — sondern die richtigen Menschen
> anzuziehen. Ein Feuer ändert seinen Standpunkt nicht. Es strahlt.

## Warum zuerst das Fundament

Bevor du auch nur einen Post veröffentlichst, musst du wissen, wer du bist — nicht Name und Beruf, sondern: Was brennt in dir? Wofür stehst du? Warum ausgerechnet du? Ohne dieses Fundament bleibt jeder Post austauschbar, und austauschbar bleibt unsichtbar.

## Die 9 Bereiche

| Bereich | Frage | Worauf es ankommt |
| --- | --- | --- |
| 🔥 **Feuer** | Wer bist du? | „Ich bin … und ich sorge dafür, dass …". Nicht der Beruf — die Geschichte, die Wendepunkte. Je ehrlicher, desto schärfer. |
| 🪵 **Holz** | Dein Warum | Warum Social Media, warum dieses Thema, warum du? Das **„Weil"** muss dabei sein, verbunden mit deiner Geschichte. |
| ☀️ **Wärme** | Was strahlst du aus? | 3–5 Werte im Format „Wert … weil …". Werte sind nicht Deko — sie entscheiden, wen du anziehst. |
| 👥 **Menschen** | Deine Zielgruppe | Kein „Frauen 25–45". Ein echter Mensch: Alltag, Lebenssituation — und die **stillen inneren Fragen** („Bin ich gut genug?"). Das ist das Gold. |
| 🌧️ **Regen** | Hindernisse | Deine eigenen Hindernisse machen dich glaubwürdig. Die Hindernisse deiner Zielgruppe sind dein Content. |
| 🕯️ **Andere Feuer** | Mitbewerber | 2–3 Accounts. Nicht kopieren — analysieren. „Ich bin anders, weil …" ist ein Satz über Einzigartigkeit, nicht über Bessersein. |
| 🌙 **Nacht** | Dein Markt | Was wird diskutiert? Welche Haltung nimmst du ein? Setz deinen eigenen Kurs. |
| 💭 **Innere Stimmen** | Blockaden | Sätze, die niemand laut sagt („Wer bin ich, dass ich das sage"). Das sind die Hooks mit Reichweite. |
| 💎 **Angebot** | Was verkaufst du? | Was, für wen, welches **Ergebnis** (das Leben danach, nicht der Prozess). |

## Drei Arten von Glück (Tiefe deines Warums)

Ein Warum, das durch schlechte Wochen trägt, ist in allen drei verankert:
1. **Glück durch Erfahrung** — was du erleben willst (außenabhängig).
2. **Glück durch Wachstum** — was du in dir entwickelst (kann dir niemand nehmen).
3. **Glück durch Beitrag** — anderen helfen (der tiefste Antrieb).

## Brand-Archetyp (optional schärfend)

Jede starke Marke hat einen Charakter, den du bewusst wählst — z. B. Held, Rebell, Weiser, Entdecker, Liebende, Narr, Fürsorger, Schöpfer, Anführer, Jedermann, Zauberer, Unschuld. Farben, Vokabular, Energie leiten sich daraus ab.

## Das Ergebnis

Aus den 9 Bereichen entsteht ein **Positionierungs-Statement** (2–3 Sätze, Ich-Form, in 30 Sek. verständlich) plus die Bausteine darum herum. Das wandert in `context/positionierung.md` und ist ab dann die Quelle für alles Weitere.

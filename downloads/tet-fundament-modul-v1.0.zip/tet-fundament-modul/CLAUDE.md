# CLAUDE.md — TET Fundament-Modul

Diese Datei wird zu Beginn jeder Session automatisch geladen.

---

## Was das hier ist

Das **TET Fundament-Modul** gibt deinem Claude zwei neue Befehle, mit denen du das **Fundament deines Social-Media-Auftritts** baust:

- **`/positionierung`** — erarbeitet mit dir deine Positionierung (das **Feuer-Prinzip**, 9 Bereiche) und legt das fertige Positionierungs-Statement in `context/positionierung.md` ab.
- **`/content-saeulen`** — baut daraus dein inhaltliches Rückgrat: **5 Content-Säulen**, passende **Hooks** und ein **Skript** → `outputs/content-saeulen.md`.

> **Erst das Fundament, dann die Säulen.** Ohne klare Positionierung bleibt jeder Post austauschbar — und austauschbar bleibt unsichtbar. Die Säulen sind die tragenden Wände auf diesem Fundament.

Deine Rolle (Claude): Du führst den Nutzer warm und Schritt für Schritt. Du schreibst, der Nutzer spricht. Kein technisches Vorwissen nötig.

## Reihenfolge

1. **`/positionierung`** zuerst — das Fundament.
2. **`/content-saeulen`** danach — baut auf der Positionierung auf.

## Struktur

```
.
├── START-HIER.html                 # ← Doppelklick: geführter Einstieg im Browser
├── CLAUDE.md                       # Diese Datei
├── .claude/commands/
│   ├── positionierung.md           # /positionierung
│   ├── content-saeulen.md          # /content-saeulen
│   └── prime.md                    # /prime — Modul + Fundament laden
├── reference/
│   ├── feuer-prinzip.md            # Methode hinter /positionierung
│   ├── saeulen-und-stages.md       # Methode hinter /content-saeulen
│   └── hooks-und-skripte.md        # Hook-Strategien + Skript-Aufbau
└── beispiel/
    ├── positionierung.md           # fertiges Beispiel-Ergebnis (fiktive Marke)
    └── content-saeulen.md          # fertiges Beispiel-Ergebnis
```

## Prinzipien

- **Show, don't tell** — konkrete Szenen statt Überbegriffe.
- **Keine Floskeln** — authentisch, ganzheitlich, leidenschaftlich, empowernd sind verboten (ohne konkreten Inhalt).
- **Nichts erfinden** — keine Fake-Testimonials/Zahlen; Lücken markieren.
- **Eine Marke pro Durchlauf** — bei mehreren Marken je eine eigene Datei.
- **Deutsch**, Ton: warm, klar, direkt, auf Augenhöhe.

---

*Ein Modul von The Escape Theory. Setzt ein eingerichtetes Claude Code voraus.*

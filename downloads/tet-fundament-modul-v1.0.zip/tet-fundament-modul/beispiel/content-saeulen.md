# Content-Säulen — Studio Nordlicht (Beispiel)

> Komplett ausgefülltes Beispiel-Ergebnis von `/content-saeulen`, abgeleitet aus der Positionierung
> im selben Ordner. So sieht aus, was am Ende in deiner `outputs/content-saeulen.md` landet.

## 🏛️ Die 5 Säulen

### 1) Markenklarheit · *Expertise* · Problem Aware
- **Innere Stimme:** „Warum sieht man mir mein Können nicht an?"
- **Kernbotschaft:** Das Problem ist selten dein Können — es ist die Lücke zwischen dem, was du draufhast, und dem, was dein Außen zeigt.
- **Formate:** Karussell (3-Punkte-Reframe), Talking-Head-Reel.
- **Hooks:** „Du bist in deinem Job richtig gut. Dein Auftritt erzählt was anderes." · „Deine Kund:innen entscheiden in Sekunden — über das, was sie sehen, nicht über das, was du kannst." · „Die teuerste Lücke deiner Selbstständigkeit ist unsichtbar."

### 2) Hinter dem Studio · *Mensch* · Unaware
- **Innere Stimme:** „Marke fühlt sich an wie Maske."
- **Kernbotschaft:** Hinter jeder klaren Marke sitzt ein Mensch mit Bauchgefühl — auch hinter meiner.
- **Formate:** Story-Behind-the-Scenes, Reel „ein Tag im Studio".
- **Hooks:** „Zwei Jahre habe ich hinter einem Logo gearbeitet, das nicht zu mir passte." · „Was ich an einem Markenprozess mache, das niemand sieht:" · „Mein erstes eigenes Logo war eine Lüge. Hier ist, was ich gelernt habe."

### 3) Vorher / Nachher · *Social Proof* · Consideration
- **Innere Stimme:** „Schaffe ich das auch?"
- **Kernbotschaft:** Es geht nicht ums hübschere Logo — es geht darum, wie jemand danach durch seine Akquise geht.
- **Formate:** Case-Karussell (als Geschichte, nicht als Zahl), Kund:innen-Stimme.
- **Hooks:** „Vor 6 Wochen hat sie ihren Preis geflüstert. Heute nennt sie ihn." · „Was sich ändert, ist nicht das Logo — es ist ihr Auftreten." *(echte Story einsetzen)*

### 4) So sieht „klar" aus · *Lifestyle* · Unaware
- **Innere Stimme:** „Ich will sichtbar sein, ohne mich zum Affen zu machen."
- **Kernbotschaft:** Sichtbarkeit ist nicht laut — sie ist klar. So fühlt sich das an.
- **Formate:** Reel mit ruhigen Studio-Szenen, Quote-Karussell.
- **Hooks:** „Sichtbar werden heißt nicht lauter werden." · „Klarheit ist kein Ego. Klarheit ist Respekt vor deiner Arbeit." · „So sieht ein Auftritt aus, der nicht mehr kleiner macht."

### 5) Der Branding-Prozess · *Angebot* · Consideration
- **Innere Stimme:** „Was passiert da eigentlich genau?"
- **Kernbotschaft:** 6 Wochen von der Haltung bis zum fertigen Auftritt — Klarheit zuerst, das Visuelle als Folge.
- **Formate:** Prozess-Karussell, Reel „so arbeiten wir zusammen".
- **Hooks:** „Du willst kein neues Logo. Du willst eine Marke, die trägt." · „Was in 6 Wochen passiert, wenn dein Auftritt endlich nach dir klingt:" · „Zeig mir deinen Auftritt — ich zeig dir die Lücke."

## 🎬 Beispiel-Skript · Säule 1 (Markenklarheit) · Problem Aware

- **Einstiegs-Emotion:** Scham (Brust zieht sich zusammen) → **Abschluss:** Erleichterung
- **HOOK (1–3):** „Du bist in deinem Job richtig gut. Dein Auftritt erzählt was anderes."
- **SZENE (4–20):** Du sitzt im Kennenlerngespräch, lieferst Gold. Am Ende: „Ich schau's mir nochmal in Ruhe an." Sie kommt nicht wieder. Und du denkst: Lag's an mir?
- **WENDUNG / ERKENNTNIS (21–35):** Es lag nicht an deinem Können. Es lag an der Lücke zwischen dem, was du draufhast, und dem, was dein Außen davon zeigt. Diese Lücke füllt ihr Kopf — meistens mit Zweifel.
- **BOGEN (36–45):** Wenn dein Auftritt so souverän ist wie deine Arbeit, passiert etwas: Sie ist überzeugt, bevor das Gespräch endet. Kein Nachfassen. Kein „ich melde mich".
- **CTA (45–50):** „Speicher dir das — und schau dir morgen deinen Auftritt mit ihren Augen an."

## 📅 Wochen-Mischung (Richtwert)
- 2× Reichweite (Mensch / Lifestyle), 2× Vertrauen (Markenklarheit), 1× Verkauf (Social Proof **oder** Angebot — mind. 1× pro Woche).

# Positionierung — Studio Nordlicht (Beispiel)

> Komplett ausgefülltes Beispiel-Ergebnis von `/positionierung` an einer fiktiven Marke (Branding-Designerin
> für Selbstständige). So sieht aus, was am Ende in deiner `context/positionierung.md` landet.

**Marke:** Studio Nordlicht · Branding & Markenaufbau für Selbstständige

### Wer du bist
Ich bin Branding-Designerin — aber eigentlich bin ich die, die übersetzt, was du längst in dir trägst und nur nicht in Worte und Bilder fassen kannst. Ich habe selbst zwei Jahre hinter einem Logo versteckt gearbeitet, das „professionell" aussah und sich angefühlt hat wie ein fremder Mantel. Erst als mein Auftritt endlich nach mir klang, kamen die richtigen Kund:innen. Dafür stehe ich: Marken, die nicht hübsch sind, sondern wahr.

### Dein Warum
Ich weiß, wie es ist, viel zu können und trotzdem übersehen zu werden — nur weil der Auftritt das Können kleiner macht, als es ist. Ich baue Marken, damit fähige Menschen aufhören, sich unter Wert zu verkaufen.

### Was du ausstrahlst
Klarheit statt Deko. Mut zur Kante statt Gefälligkeit. Wärme, weil hinter jeder Marke ein Mensch mit Bauchgefühl sitzt. Ich sage, was eine Marke trägt — auch wenn es unbequem ist.

### Für wen du leuchtest
Selbstständige Frauen zwischen 30 und 50, die in ihrem Handwerk richtig gut sind und trotzdem das Gefühl haben, „noch nicht ernst genommen" zu werden. Sie schieben den Markenauftritt seit Monaten vor sich her. Innerlich fragen sie sich: *„Wirke ich eigentlich so unprofessionell, wie ich mich fühle?"* und *„Wer bin ich, eine starke Marke zu beanspruchen?"*

### Was dich authentisch macht
Ich habe selbst zwei Jahre mit einem Auftritt gearbeitet, der nicht zu mir passte — und genau gespürt, wie das Selbstvertrauen mitschrumpft. Ich verkaufe keine Theorie. Ich war da.

### Wo du anders bist
Die meisten liefern dir ein schönes Logo und lassen dich damit allein. Ich fange eine Ebene tiefer an: bei der Haltung, der Botschaft, dem „Wofür". Das Visuelle ist die Folge, nicht der Anfang.

### Dein Markt & Timing
„Personal Branding" ist überall — aber meist als Selbstinszenierung missverstanden. Meine Haltung: Branding ist nicht lauter werden, sondern klarer. Genau da ist die Sehnsucht gerade am größten.

### Content aus inneren Stimmen
- „Ich bin gut in dem, was ich tue — warum sieht man mir das nicht an?"
- „Ein neues Logo fühlt sich an wie Angeberei."
- „Ich will sichtbar sein, ohne mich zum Affen zu machen."
- „Alle sehen schon so fertig aus — ich wirke daneben wie ein Hobby."
- „Wenn ich mich festlege, schließe ich Kund:innen aus."

### Dein Angebot in Position
Ich begleite dich in einem 6-Wochen-Branding-Prozess von der Haltung bis zum fertigen Auftritt — damit dein Außen endlich zu deinem Können passt.

### 🎯 Positionierungs-Statement
Ich mache aus fähigen Selbstständigen sichtbare Marken — nicht durch lauter, sondern durch klarer. Ich bringe das, wofür du stehst, in Worte und Bilder, die endlich nach dir klingen. Damit dein Auftritt nicht mehr kleiner macht, als du bist.

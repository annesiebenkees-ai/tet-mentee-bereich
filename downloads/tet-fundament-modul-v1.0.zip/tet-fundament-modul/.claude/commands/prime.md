# /prime — Fundament-Modul laden

> Lädt den Kontext dieses Moduls und (falls vorhanden) dein bestehendes Fundament.

## Lesen
- `CLAUDE.md`
- alle Dateien in `./context/` (falls vorhanden)

## Danach
Fasse kurz zusammen, was du über die Marke des Nutzers weißt, und nenne die zwei verfügbaren Befehle:
- `/positionierung` — Fundament erarbeiten (Feuer-Prinzip)
- `/content-saeulen` — 5 Säulen, Hooks & Skripte daraus bauen

Wenn noch keine Positionierung existiert, empfiehl, mit `/positionierung` zu starten.
